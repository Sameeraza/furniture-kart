package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Frosted Glass Theme Palette (Indigo, Purple, Soft Slate, Pastel Grey)
val Indigo600 = Color(0xFF4F46E5)      // Primary Indigo
val Indigo400 = Color(0xFF818CF8)      // Secondary Indigo
val VividOrange = Color(0xFFF97316)    // Accent Orange
val LightGlassBg = Color(0xFFF3F4F9)   // Main Background Pastel Grey-Blue
val SlateText = Color(0xFF1E293B)      // Primary text color (Slate 800)

// Glass Translucency simulations
val GlassWhite80 = Color(0xCCFFFFFF)   // White with 80% opacity
val GlassWhite60 = Color(0x99FFFFFF)   // White with 60% opacity
val GlassWhite40 = Color(0x66FFFFFF)   // White with 40% opacity
val GlassBorder = Color(0x40FFFFFF)    // White border with 25% opacity

// Dark Theme equivalents
val DeepSlateBg = Color(0xFF0F172A)    // Dark Indigo-Slate background
val NeonIndigo = Color(0xFF6366F1)     // Dark Mode primary
val NeonPurple = Color(0xFF8B5CF6)     // Dark Mode secondary
val GlassDark60 = Color(0x991E293B)    // Semi-translucent dark slate surface
val GlassDarkBorder = Color(0x25FFFFFF) // Subtle dark border


