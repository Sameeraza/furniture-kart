package com.example.ui.viewmodel

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class FurnitureViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FurnitureRepository
    private val context: Context = application.applicationContext

    // Cloud Sync Configuration
    private val _cloudSyncConfig = MutableStateFlow(CloudSyncConfigManager.getConfig(context))
    val cloudSyncConfig: StateFlow<CloudSyncConfig> = _cloudSyncConfig.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncMessage = MutableStateFlow<String?>(null)
    val syncMessage: StateFlow<String?> = _syncMessage.asStateFlow()

    fun updateCloudSyncConfig(config: CloudSyncConfig) {
        CloudSyncConfigManager.saveConfig(context, config)
        _cloudSyncConfig.value = config
    }

    fun clearSyncMessage() {
        _syncMessage.value = null
    }

    fun pushCatalogToCloud() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncMessage.value = "Uploading catalog..."
            val currentProducts = allProducts.value
            val config = _cloudSyncConfig.value
            val result = CloudSyncManager.uploadCatalog(config.channelId, currentProducts)
            if (result.isSuccess) {
                _syncMessage.value = "Successfully pushed to channel '${config.channelId}'!"
                addInAppNotification("Cloud Sync", "Store catalog uploaded to channel: ${config.channelId}")
            } else {
                _syncMessage.value = "Upload failed: ${result.exceptionOrNull()?.message}"
            }
            _isSyncing.value = false
        }
    }

    fun pullCatalogFromCloud() {
        viewModelScope.launch {
            _isSyncing.value = true
            _syncMessage.value = "Fetching catalog..."
            val config = _cloudSyncConfig.value
            val result = CloudSyncManager.fetchCatalog(config.channelId)
            if (result.isSuccess) {
                val remoteProducts = result.getOrNull()
                if (remoteProducts != null && remoteProducts.isNotEmpty()) {
                    repository.deleteAllProducts()
                    remoteProducts.forEach { repository.insertProduct(it) }
                    _syncMessage.value = "Successfully synced ${remoteProducts.size} items from channel '${config.channelId}'!"
                    addInAppNotification("Cloud Sync", "Imported ${remoteProducts.size} items from channel: ${config.channelId}")
                } else if (remoteProducts != null && remoteProducts.isEmpty()) {
                    _syncMessage.value = "Channel '${config.channelId}' has no products listed."
                } else {
                    _syncMessage.value = "No items returned from channel."
                }
            } else {
                _syncMessage.value = "Sync failed: ${result.exceptionOrNull()?.message}"
            }
            _isSyncing.value = false
        }
    }

    private fun triggerAutoPushIfNeeded() {
        if (_cloudSyncConfig.value.autoPush) {
            pushCatalogToCloud()
        }
    }

    init {
        val database = AppDatabase.getDatabase(context)
        repository = FurnitureRepository(database)
        
        // Ensure database is seeded on launch
        viewModelScope.launch {
            AppDatabase.seedIfNeeded(database)
            
            // Auto sync from cloud if enabled
            if (_cloudSyncConfig.value.autoPull) {
                pullCatalogFromCloud()
            }
        }
    }

    // Products
    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filters and Search States
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _maxPriceFilter = MutableStateFlow(150000.0)
    val maxPriceFilter: StateFlow<Double> = _maxPriceFilter.asStateFlow()

    private val _sortBy = MutableStateFlow("Popularity") // Popularity, PriceLowHigh, PriceHighLow
    val sortBy: StateFlow<String> = _sortBy.asStateFlow()

    // Combined filtered products
    val filteredProducts: StateFlow<List<Product>> = combine(
        allProducts, _searchQuery, _selectedCategory, _maxPriceFilter, _sortBy
    ) { products, query, category, maxPrice, sort ->
        var list = products.filter { product ->
            val matchesSearch = product.name.contains(query, ignoreCase = true) ||
                    product.description.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" || product.category.equals(category, ignoreCase = true)
            val matchesPrice = product.price <= maxPrice
            matchesSearch && matchesCategory && matchesPrice
        }
        
        list = when (sort) {
            "PriceLowHigh" -> list.sortedBy { it.price }
            "PriceHighLow" -> list.sortedByDescending { it.price }
            "Rating" -> list.sortedByDescending { it.rating }
            else -> list.sortedByDescending { it.id } // Default latest
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Profile
    val userProfile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Wishlist items
    val wishlistItems: StateFlow<List<WishlistItem>> = repository.wishlistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart items mapped to detailed product information
    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartWithProductList: StateFlow<List<CartItemWithProduct>> = combine(
        cartItems, allProducts
    ) { items, products ->
        items.mapNotNull { cartItem ->
            val product = products.find { it.id == cartItem.productId }
            if (product != null) {
                CartItemWithProduct(cartItem, product)
            } else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartSubtotal: StateFlow<Double> = cartWithProductList.map { list ->
        list.sumOf { it.product.price * it.cartItem.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // All historic customer orders
    val allOrders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // In-app notifications/alerts history
    private val _notifications = MutableStateFlow<List<InAppNotification>>(emptyList())
    val notifications: StateFlow<List<InAppNotification>> = _notifications.asStateFlow()

    // Admin specific alerts
    private val _adminAlerts = MutableStateFlow<List<InAppNotification>>(emptyList())
    val adminAlerts: StateFlow<List<InAppNotification>> = _adminAlerts.asStateFlow()

    fun addAdminAlert(title: String, message: String) {
        val newAlert = InAppNotification(title = title, message = message)
        _adminAlerts.update { listOf(newAlert) + it }
    }

    fun clearAdminAlerts() {
        _adminAlerts.value = emptyList()
    }

    // Interactive Checkout Progress & State
    private val _checkoutState = MutableStateFlow<CheckoutUiState>(CheckoutUiState.Idle)
    val checkoutState: StateFlow<CheckoutUiState> = _checkoutState.asStateFlow()

    // Setup filter operations
    fun setSearchQuery(query: String) { _searchQuery.value = query }
    fun setSelectedCategory(category: String) { _selectedCategory.value = category }
    fun setMaxPriceFilter(maxPrice: Double) { _maxPriceFilter.value = maxPrice }
    fun setSortBy(sort: String) { _sortBy.value = sort }

    // Cart Actions
    fun addToCart(productId: Int, quantity: Int = 1) {
        viewModelScope.launch {
            // Check stock first
            val products = allProducts.value
            val target = products.find { it.id == productId }
            if (target != null && target.stock > 0) {
                repository.addToCart(productId, quantity)
                addInAppNotification("Item Added", "${target.name} has been added to your cart.")
            } else {
                addInAppNotification("Out of Stock", "Sorry, this item is temporarily out of stock.")
            }
        }
    }

    fun updateCartItemQuantity(cartItemId: Int, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateCartItemQuantity(cartItemId, newQuantity)
        }
    }

    fun removeFromCart(cartItemId: Int) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
        }
    }

    // Wishlist Actions
    fun toggleWishlist(productId: Int) {
        viewModelScope.launch {
            repository.toggleWishlist(productId)
            val product = allProducts.value.find { it.id == productId } ?: return@launch
            val isWishlistedNow = wishlistItems.value.none { it.productId == productId }
            addInAppNotification(
                title = if (isWishlistedNow) "Wishlist Added" else "Wishlist Removed",
                message = if (isWishlistedNow) "${product.name} has been added to your wishlist." else "${product.name} was removed."
            )
        }
    }

    fun isProductWishlisted(productId: Int): Flow<Boolean> = repository.isWishlisted(productId)

    // Reviews Actions
    fun getProductReviews(productId: Int): Flow<List<Review>> = repository.getReviewsForProduct(productId)

    fun addProductReview(productId: Int, userName: String, rating: Int, comment: String) {
        viewModelScope.launch {
            repository.addReview(productId, userName, rating, comment)
            
            // Re-calculate average rating for local product
            val reviews = getProductReviews(productId).first()
            val totalRating = reviews.sumOf { it.rating } + rating
            val newAvg = totalRating.toFloat() / (reviews.size + 1)
            
            val product = allProducts.value.find { it.id == productId }
            if (product != null) {
                repository.updateProduct(product.copy(rating = newAvg))
            }
            
            addInAppNotification("Review Posted", "Thank you for reviewing our products!")
        }
    }

    // Profile Actions
    fun updateProfile(name: String, email: String, phone: String, addresses: List<String>) {
        viewModelScope.launch {
            val updated = UserProfile(
                id = 1,
                name = name,
                email = email,
                phone = phone,
                savedAddresses = addresses.joinToString(";")
            )
            repository.updateProfile(updated)
            addInAppNotification("Profile Updated", "Your profile details have been saved successfully.")
        }
    }

    fun addNewAddress(newAddress: String) {
        viewModelScope.launch {
            val currentProfile = userProfile.value ?: UserProfile(name = "User", email = "", phone = "", savedAddresses = "")
            val updatedAddresses = if (currentProfile.savedAddresses.isEmpty()) {
                newAddress
            } else {
                "${currentProfile.savedAddresses};$newAddress"
            }
            repository.updateProfile(currentProfile.copy(savedAddresses = updatedAddresses))
            addInAppNotification("Address Added", "A new delivery address was saved to your profile.")
        }
    }

    // Secure Payment checkout and order fulfillment flow
    fun processCheckout(shippingAddress: String, paymentMethod: String, cardNumber: String, cvv: String, expiry: String) {
        viewModelScope.launch {
            _checkoutState.value = CheckoutUiState.ProcessingPayment
            
            val isUpi = paymentMethod.startsWith("UPI")
            val isCod = paymentMethod.startsWith("Cash on Delivery") || paymentMethod.startsWith("COD") || paymentMethod.startsWith("WhatsApp")

            // Validate billing credentials (mocking check)
            if (isCod) {
                // Cash on Delivery requires no card or online gateway validations
            } else if (isUpi) {
                if (!cardNumber.contains("@") || cardNumber.trim().length < 5) {
                    _checkoutState.value = CheckoutUiState.PaymentError("Invalid UPI ID format. Please use a valid Virtual Payment Address (e.g. name@bank or phone@upi).")
                    return@launch
                }
            } else {
                if (cardNumber.length < 16 || cvv.length < 3 || expiry.isEmpty()) {
                    _checkoutState.value = CheckoutUiState.PaymentError("Invalid payment card credentials. Please double check card security details.")
                    return@launch
                }
            }

            delay(2000) // Simulate secure bank authorization handshake delay

            val itemsList = cartWithProductList.value
            if (itemsList.isEmpty()) {
                _checkoutState.value = CheckoutUiState.PaymentError("Your cart is empty.")
                return@launch
            }

            // Deduct inventory stock levels & form items summary
            var outOfStockMsg: String? = null
            for (item in itemsList) {
                if (item.product.stock < item.cartItem.quantity) {
                    outOfStockMsg = "Sorry, ${item.product.name} has only ${item.product.stock} units remaining."
                    break
                }
            }

            if (outOfStockMsg != null) {
                _checkoutState.value = CheckoutUiState.PaymentError(outOfStockMsg)
                return@launch
            }

            // Perform inventory deduction
            for (item in itemsList) {
                val newStock = item.product.stock - item.cartItem.quantity
                repository.updateStock(item.product.id, newStock)
            }

            val itemsSummaryStr = itemsList.joinToString(", ") { "${it.product.name} x${it.cartItem.quantity}" }
            val orderTotal = cartSubtotal.value + 15.0 // Add $15 flat delivery shipping

            val profile = userProfile.value
            val custName = profile?.name ?: "Sarah Jenkins"
            val custPhone = if (profile?.phone.isNullOrBlank()) "+1 (555) 432-8765" else profile?.phone ?: ""
            val custEmail = if (profile?.email.isNullOrBlank()) "sarah.jenkins@gmail.com" else profile?.email ?: ""

            // Save order in Database
            val orderId = repository.placeOrder(
                totalAmount = orderTotal,
                address = shippingAddress,
                paymentMethod = paymentMethod,
                itemsSummary = itemsSummaryStr,
                customerName = custName,
                customerEmail = custEmail,
                customerPhone = custPhone
            )

            // Success checkout state
            _checkoutState.value = CheckoutUiState.Success(orderId.toInt())
            
            // Clear shopping cart
            repository.clearCart()

            // Fetch current customer profile info
            val customerName = profile?.name ?: "Guest Customer"
            val customerPhone = if (!profile?.phone.isNullOrBlank()) profile?.phone else "N/A"
            val customerEmail = if (!profile?.email.isNullOrBlank()) profile?.email else "N/A"

            // Handle Currency representation: Strictly in Indian Rupees (INR)
            val formattedTotal = "₹${String.format(Locale.US, "%.2f", orderTotal)}"

            // Raise System notifications and logs
            triggerSystemPushNotification("Order Confirmed", "Your payment of $formattedTotal was processed successfully. Order #$orderId is placed.")
            addInAppNotification("Payment Confirmed", "Secure payment processed ($formattedTotal). Order #$orderId is now in production.")

            // Raise Admin panel store-owner notification
            addAdminAlert(
                title = "New Purchase (Order #FKT-$orderId)",
                message = "Customer: $customerName\nContact: $customerPhone ($customerEmail)\nItems: $itemsSummaryStr\nDeliver To: $shippingAddress\nPayment Method: $paymentMethod\nTotal Received: $formattedTotal"
            )

            // Trigger Automated SMTP Email Alert if enabled
            val smtp = _smtpConfig.value
            if (smtp.enabled) {
                viewModelScope.launch {
                    val emailSubject = "[FurnitureKart] New Purchase Order #FKT-$orderId Completed!"
                    val emailBody = """
                        Hello Admin,

                        A new purchase order has been successfully placed on FurnitureKart!

                        Order Details:
                        --------------------------------------------------
                        Order Reference: #FKT-$orderId
                        Customer Name: $customerName
                        Customer Phone: $customerPhone
                        Customer Email: $customerEmail
                        Shipping Address: $shippingAddress
                        Payment Method: $paymentMethod
                        Items Ordered: $itemsSummaryStr
                        Total Paid: $formattedTotal
                        --------------------------------------------------

                        You can manage this order directly in the FurnitureKart Store Control Panel.

                        Warm regards,
                        FurnitureKart Automated Order System
                    """.trimIndent()
                    
                    val emailResult = EmailSender.sendEmail(smtp, emailSubject, emailBody)
                    if (emailResult.isFailure) {
                        android.util.Log.e("FurnitureViewModel", "Failed to send automated purchase order email alert", emailResult.exceptionOrNull())
                        addAdminAlert(
                            title = "Email Delivery Alert Failed",
                            message = "Could not send automated purchase order email alert to ${smtp.recipient}. Error: ${emailResult.exceptionOrNull()?.message}"
                        )
                    } else {
                        android.util.Log.d("FurnitureViewModel", "Automated email alert sent successfully to ${smtp.recipient}")
                    }
                }
            }

            // Start Order Delivery Tracking Background Updates simulation
            simulateRealTimeOrderTracking(orderId.toInt())
        }
    }

    fun resetCheckoutState() {
        _checkoutState.value = CheckoutUiState.Idle
    }

    // Real-Time Delivery updates simulation (auto updates status every few seconds for visual tracking demo)
    private fun simulateRealTimeOrderTracking(orderId: Int) {
        viewModelScope.launch {
            delay(10000) // 10 seconds: update 1
            repository.updateOrderStatus(
                orderId = orderId,
                status = "Processing",
                progress = 0.4f,
                logs = "Order Placed;Payment Confirmed;Processing at San Jose Warehouse;Wood carving and polishing completed"
            )
            triggerSystemPushNotification("Order Processing Update", "Order #$orderId: Wood components are fully carved and ready for assembly!")
            addInAppNotification("Order Production Update", "Order #$orderId: Structural oak components finished carving.")

            delay(10000) // Another 10 seconds: update 2
            repository.updateOrderStatus(
                orderId = orderId,
                status = "Shipped",
                progress = 0.7f,
                logs = "Order Placed;Payment Confirmed;Processing at San Jose Warehouse;Wood carving completed;Quality inspection passed;Dispatched via FurnitureExpress"
            )
            triggerSystemPushNotification("Order Dispatched", "Order #$orderId: Shipped out and in transit with FurnitureExpress!")
            addInAppNotification("Order In Transit", "Order #$orderId has been dispatched for home delivery.")

            delay(12000) // Another 12 seconds: update 3
            repository.updateOrderStatus(
                orderId = orderId,
                status = "Delivered",
                progress = 1.0f,
                logs = "Order Placed;Payment Confirmed;Processing at San Jose Warehouse;Wood carving completed;Quality inspection passed;Dispatched via FurnitureExpress;Delivered and assembled at threshold"
            )
            triggerSystemPushNotification("Order Delivered", "Order #$orderId: Your beautiful new furniture has been delivered and assembled!")
            addInAppNotification("Order Delivered", "Order #$orderId is successfully completed.")
        }
    }

    // Admin Panel Operations
    fun adminAddNewProduct(name: String, description: String, price: Double, category: String, stock: Int, material: String, dimensions: String, imageUrl: String = "") {
        viewModelScope.launch {
            val randomHexColor = listOf(0xFFD2B48C, 0xFFC6AC8F, 0xFFBC8F8F, 0xFF8B4513, 0xFFD4A373, 0xFFE0D2C3).random()
            val newProduct = Product(
                name = name,
                description = description,
                price = price,
                category = category,
                stock = stock,
                rating = 5.0f,
                imagePlaceholderColor = randomHexColor,
                dimensions = dimensions,
                material = material,
                imageUrl = imageUrl
            )
            repository.insertProduct(newProduct)
            addInAppNotification("New Product Listed", "$name has been added to the store inventory.")
            triggerAutoPushIfNeeded()
        }
    }

    fun adminUpdateProductStock(productId: Int, updatedStock: Int) {
        viewModelScope.launch {
            repository.updateStock(productId, updatedStock)
            val p = allProducts.value.find { it.id == productId }
            if (p != null) {
                addInAppNotification("Stock Restocked", "Inventory stock for ${p.name} updated to $updatedStock units.")
            }
            triggerAutoPushIfNeeded()
        }
    }

    fun adminUpdateProductPrice(productId: Int, updatedPrice: Double) {
        viewModelScope.launch {
            val p = allProducts.value.find { it.id == productId }
            if (p != null) {
                repository.updateProduct(p.copy(price = updatedPrice))
                addInAppNotification("Price Updated", "Catalog price for ${p.name} updated to ₹${String.format(Locale.US, "%.2f", updatedPrice)}.")
            }
            triggerAutoPushIfNeeded()
        }
    }

    fun adminUpdateProductDetails(
        productId: Int,
        name: String,
        description: String,
        price: Double,
        category: String,
        stock: Int,
        material: String,
        dimensions: String,
        imagePlaceholderColor: Long,
        imageUrl: String = ""
    ) {
        viewModelScope.launch {
            val p = allProducts.value.find { it.id == productId }
            if (p != null) {
                val updatedProduct = p.copy(
                    name = name,
                    description = description,
                    price = price,
                    category = category,
                    stock = stock,
                    material = material,
                    dimensions = dimensions,
                    imagePlaceholderColor = imagePlaceholderColor,
                    imageUrl = imageUrl
                )
                repository.updateProduct(updatedProduct)
                addInAppNotification("Product Updated", "$name has been updated in the catalog.")
                addAdminAlert("Product Updated", "Product #$productId ($name) details were successfully updated.")
            }
            triggerAutoPushIfNeeded()
        }
    }

    fun adminDeleteProduct(productId: Int) {
        viewModelScope.launch {
            val p = allProducts.value.find { it.id == productId }
            repository.deleteProductById(productId)
            if (p != null) {
                addInAppNotification("Product Removed", "${p.name} has been removed from catalogs.")
            }
            triggerAutoPushIfNeeded()
        }
    }

    fun adminAdvanceOrderStatus(orderId: Int) {
        viewModelScope.launch {
            val orders = allOrders.value
            val order = orders.find { it.id == orderId } ?: return@launch
            
            val (nextStatus, nextProgress, nextLogs) = when (order.status) {
                "Pending" -> Triple(
                    "Processing", 
                    0.4f, 
                    "${order.deliveryStatusLogs};Approved by admin;In crafting production"
                )
                "Processing" -> Triple(
                    "Shipped", 
                    0.7f, 
                    "${order.deliveryStatusLogs};Quality checklist verified;Dispatched from operations hub"
                )
                "Shipped" -> Triple(
                    "Delivered", 
                    1.0f, 
                    "${order.deliveryStatusLogs};Delivered at customer front porch"
                )
                else -> Triple(order.status, order.trackingProgress, order.deliveryStatusLogs)
            }

            repository.updateOrderStatus(orderId, nextStatus, nextProgress, nextLogs)
            triggerSystemPushNotification("Order Status Advanced", "Order #$orderId status changed to: $nextStatus")
            addInAppNotification("Admin Order Status", "Order #$orderId advanced to $nextStatus state.")
        }
    }

    // In-App Notification Helper
    private fun addInAppNotification(title: String, message: String) {
        val newNotif = InAppNotification(title = title, message = message)
        _notifications.update { listOf(newNotif) + it }
    }

    // SMTP Email Settings
    private val _smtpConfig = MutableStateFlow(EmailSender.getSmtpConfig(context))
    val smtpConfig: StateFlow<SmtpConfig> = _smtpConfig.asStateFlow()

    fun updateSmtpConfig(config: SmtpConfig) {
        EmailSender.saveSmtpConfig(context, config)
        _smtpConfig.value = config
    }

    fun sendTestEmail(config: SmtpConfig, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = EmailSender.sendEmail(
                config = config,
                subject = "[FurnitureKart] SMTP Test Email",
                body = "Hello! If you are reading this email, your FurnitureKart SMTP automated email alert integration is working perfectly.\n\nRecipient: ${config.recipient}"
            )
            if (result.isSuccess) {
                onResult(true, "Test email sent successfully to ${config.recipient}!")
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "Unknown error occurred.")
            }
        }
    }

    // Secure Admin Bank Account Connection Configuration
    private val _bankConfig = MutableStateFlow(BankConnectionManager.getBankConfig(context))
    val bankConfig: StateFlow<BankConfig> = _bankConfig.asStateFlow()

    fun updateBankConfig(config: BankConfig) {
        BankConnectionManager.saveBankConfig(context, config)
        _bankConfig.value = config
    }

    // Secure Admin Support Configuration
    private val _supportConfig = MutableStateFlow(SupportConfigManager.getSupportConfig(context))
    val supportConfig: StateFlow<SupportConfig> = _supportConfig.asStateFlow()

    fun updateSupportConfig(config: SupportConfig) {
        SupportConfigManager.saveSupportConfig(context, config)
        _supportConfig.value = config
    }

    // Android System level push notification support
    @android.annotation.SuppressLint("NotificationPermission", "MissingPermission")
    private fun triggerSystemPushNotification(title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "furniture_order_alerts"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Furniture Order Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications about furniture order production and shipping"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        try {
            notificationManager.notify(UUID.randomUUID().hashCode(), builder.build())
        } catch (e: SecurityException) {
            // Permission not granted or required, we still record via in-app logs safely
        }
    }
}

// Helper container models
data class CartItemWithProduct(
    val cartItem: CartItem,
    val product: Product
)

data class InAppNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface CheckoutUiState {
    object Idle : CheckoutUiState
    object ProcessingPayment : CheckoutUiState
    data class Success(val orderId: Int) : CheckoutUiState
    data class PaymentError(val errorMessage: String) : CheckoutUiState
}
