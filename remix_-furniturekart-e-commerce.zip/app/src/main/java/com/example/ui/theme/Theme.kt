package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// Custom extension for Glass Background gradient
@Composable
fun Modifier.glassBackground(): Modifier {
  val isDark = isSystemInDarkTheme()
  val brush = if (isDark) {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFF0F172A), // Slate 900
        Color(0xFF1E1B4B), // Indigo 950
        Color(0xFF0F172A)  // Slate 900
      )
    )
  } else {
    Brush.verticalGradient(
      colors = listOf(
        Color(0xFFE8EBF4), // Pale lavender-grey
        Color(0xFFF3F4F9), // Light grey-blue
        Color(0xFFE2E7F3)  // Soft pastel grey-indigo
      )
    )
  }
  return this.background(brush)
}

// Custom extension for Frosted Glass styling
@Composable
fun Modifier.frostedGlass(
  shape: Shape = RoundedCornerShape(24.dp),
  lightOpacity: Float = 0.5f,
  darkOpacity: Float = 0.25f,
  borderOpacity: Float = 0.5f
): Modifier {
  val isDark = isSystemInDarkTheme()
  val bgColor = if (isDark) {
    Color(0xFF1E293B).copy(alpha = darkOpacity)
  } else {
    Color.White.copy(alpha = lightOpacity)
  }
  val borderColor = if (isDark) {
    Color.White.copy(alpha = 0.12f)
  } else {
    Color.White.copy(alpha = borderOpacity)
  }
  return this.then(
    Modifier
      .clip(shape)
      .background(bgColor)
      .border(width = 1.dp, color = borderColor, shape = shape)
  )
}

private val DarkColorScheme =
  darkColorScheme(
    primary = NeonIndigo,
    secondary = NeonPurple,
    tertiary = VividOrange,
    background = DeepSlateBg,
    surface = GlassDark60,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    onBackground = androidx.compose.ui.graphics.Color.White,
    onSurface = androidx.compose.ui.graphics.Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Indigo600,
    secondary = Indigo400,
    tertiary = VividOrange,
    background = LightGlassBg,
    surface = GlassWhite80,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = Indigo600,
    onBackground = SlateText,
    onSurface = SlateText
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamicColor to enforce our Frosted Glass design language
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
