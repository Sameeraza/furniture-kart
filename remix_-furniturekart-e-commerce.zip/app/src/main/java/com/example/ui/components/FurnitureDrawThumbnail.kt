package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.Weekend
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KingBed
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.TableRestaurant
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun FurnitureDrawThumbnail(
    category: String,
    placeholderColor: Long,
    modifier: Modifier = Modifier,
    imageUrl: String = ""
) {
    val baseColor = Color(placeholderColor)
    val startGradientColor = baseColor.copy(alpha = 0.85f)
    val endGradientColor = baseColor.copy(alpha = 0.4f)
    
    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(startGradientColor, endGradientColor)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!imageUrl.isNullOrBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = "$category picture",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Overlay a neat geometric abstract circle backdrop
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(45.dp))
            )
            
            // Render stylized high-contrast Material icons representing the category
            val (icon, size) = when (category.lowercase()) {
                "sofa" -> Pair(Icons.Default.Weekend, 48.dp)
                "chair" -> Pair(Icons.Default.Chair, 48.dp)
                "table" -> Pair(Icons.Default.TableRestaurant, 48.dp)
                "bed" -> Pair(Icons.Default.KingBed, 52.dp)
                "decor" -> Pair(Icons.Default.Lightbulb, 44.dp)
                else -> Pair(Icons.Default.Home, 48.dp)
            }
            
            Icon(
                imageVector = icon,
                contentDescription = "$category thumbnail",
                modifier = Modifier.size(size),
                tint = Color.White
            )
        }
    }
}
