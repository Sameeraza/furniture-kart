package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import com.example.ui.viewmodel.CartItemWithProduct
import java.util.Locale
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.FurnitureDrawThumbnail
import com.example.ui.theme.frostedGlass
import com.example.ui.theme.glassBackground
import com.example.ui.viewmodel.CheckoutUiState
import com.example.ui.viewmodel.FurnitureViewModel
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// 1. CUSTOMER DASHBOARD SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDashboardScreen(
    viewModel: FurnitureViewModel,
    onNavigateToProduct: (Int) -> Unit,
    onNavigateToCart: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val cartWithProducts by viewModel.cartWithProductList.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val maxPriceFilter by viewModel.maxPriceFilter.collectAsStateWithLifecycle()
    val sortBy by viewModel.sortBy.collectAsStateWithLifecycle()

    var showAdminLoginDialog by remember { mutableStateOf(false) }
    var adminPinInput by remember { mutableStateOf("") }
    var adminPinError by remember { mutableStateOf(false) }
    var adminPinAttempts by remember { mutableStateOf(0) }
    var adminPinLockoutSeconds by remember { mutableStateOf(0) }

    LaunchedEffect(adminPinLockoutSeconds) {
        if (adminPinLockoutSeconds > 0) {
            kotlinx.coroutines.delay(1000)
            adminPinLockoutSeconds -= 1
        }
    }

    val allProductsState by viewModel.allProducts.collectAsStateWithLifecycle()
    val categories = remember(allProductsState) {
        listOf("All") + allProductsState.map { it.category }.distinct().filter { it.isNotBlank() }.sorted()
    }
    val cartCount = cartWithProducts.sumOf { it.cartItem.quantity }

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text(
                            "FurnitureKart",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 28.sp
                        )
                        Text(
                            "Curated pieces for conscious living",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }
                },
                actions = {
                    // Cloud Sync Pull Shortcut
                    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
                    val syncMessage by viewModel.syncMessage.collectAsStateWithLifecycle()
                    val context = LocalContext.current

                    LaunchedEffect(syncMessage) {
                        syncMessage?.let {
                            android.widget.Toast.makeText(context, it, android.widget.Toast.LENGTH_SHORT).show()
                            viewModel.clearSyncMessage()
                        }
                    }

                    IconButton(
                        onClick = { viewModel.pullCatalogFromCloud() },
                        enabled = !isSyncing,
                        modifier = Modifier.testTag("nav_sync_button")
                    ) {
                        if (isSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = "Sync Cloud Catalog",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Profile Shortcut
                    IconButton(
                        onClick = onNavigateToProfile,
                        modifier = Modifier.testTag("nav_profile_button")
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "User Profile", tint = MaterialTheme.colorScheme.primary)
                    }

                    // Admin Shortcut
                    IconButton(
                        onClick = { showAdminLoginDialog = true },
                        modifier = Modifier.testTag("nav_admin_button")
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin Operations", tint = MaterialTheme.colorScheme.tertiary)
                    }

                    // Shopping Cart Badge Shortcut
                    Box(contentAlignment = Alignment.TopEnd) {
                        IconButton(
                            onClick = onNavigateToCart,
                            modifier = Modifier.testTag("nav_cart_button")
                        ) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = "Shopping Bag", tint = MaterialTheme.colorScheme.primary)
                        }
                        if (cartCount > 0) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(18.dp)
                                    .background(MaterialTheme.colorScheme.tertiary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cartCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent, // Ensure background shows through
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground() // Beautiful radial/linear fluid background gradient
        ) {
            // Search Input Block (Frosted Glass style)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.7f, borderOpacity = 0.5f)
                    .testTag("search_input"),
                placeholder = { Text("Search elegant sofas, lamps, tables...", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear Search", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    disabledBorderColor = Color.Transparent,
                    errorBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                ),
                singleLine = true
            )

            // Hero Promotion Banner (Frosted Glass Theme matching the Design HTML)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF6366F1), // Indigo 500
                                Color(0xFF9333EA)  // Purple 600
                            )
                        )
                    )
            ) {
                // Background artistic pattern simulation using shapes
                Box(
                    modifier = Modifier
                        .offset(x = 180.dp, y = (-20).dp)
                        .size(160.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                )
                Box(
                    modifier = Modifier
                        .offset(x = 100.dp, y = 60.dp)
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                )

                // Bottom banner overlay matching Design HTML glass effect
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .frostedGlass(
                            shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
                            lightOpacity = 0.25f,
                            darkOpacity = 0.15f,
                            borderOpacity = 0.3f
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "SEASON SALE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.9f),
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Nordic Minimalism",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.25f))
                                .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "40% OFF",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Category Horizontal Tabs
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                edgePadding = 16.dp,
                divider = {},
                indicator = {},
                containerColor = Color.Transparent,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .then(
                                if (isSelected) {
                                    Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(MaterialTheme.colorScheme.primary)
                                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                                } else {
                                    Modifier.frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.3f)
                                }
                            )
                            .clickable { viewModel.setSelectedCategory(category) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("category_tab_$category"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = category,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Price and Sorting Control Drawer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(0.55f)) {
                    Text(
                        text = "Max Price: ₹${maxPriceFilter.toInt()}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = maxPriceFilter.toFloat(),
                        onValueChange = { viewModel.setMaxPriceFilter(it.toDouble()) },
                        valueRange = 50f..150000f,
                        modifier = Modifier
                            .height(24.dp)
                            .testTag("price_filter_slider"),
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Sorting selector
                var showSortMenu by remember { mutableStateOf(false) }
                Box(modifier = Modifier.weight(0.45f)) {
                    OutlinedButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                            .testTag("sort_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when (sortBy) {
                                    "PriceLowHigh" -> "Price: Low to High"
                                    "PriceHighLow" -> "Price: High to Low"
                                    "Rating" -> "Top Rated"
                                    else -> "Popularity"
                                },
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Popularity") },
                            onClick = { viewModel.setSortBy("Popularity"); showSortMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Price: Low to High") },
                            onClick = { viewModel.setSortBy("PriceLowHigh"); showSortMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Price: High to Low") },
                            onClick = { viewModel.setSortBy("PriceHighLow"); showSortMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Top Rated") },
                            onClick = { viewModel.setSortBy("Rating"); showSortMenu = false }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Products Grid view
            if (products.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.Inventory,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "No furniture pieces found",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        Text(
                            "Try modifying your filter settings or search query",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                viewModel.setSearchQuery("")
                                viewModel.setSelectedCategory("All")
                                viewModel.setMaxPriceFilter(1000.0)
                                viewModel.setSortBy("Popularity")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Reset All Filters")
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                        .testTag("products_grid"),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(products, key = { it.id }) { product ->
                        ProductGridItem(
                            product = product,
                            onProductClick = { onNavigateToProduct(product.id) },
                            onAddToCart = { viewModel.addToCart(product.id) }
                        )
                    }
                }
            }

            if (showAdminLoginDialog) {
                AlertDialog(
                    onDismissRequest = { 
                        showAdminLoginDialog = false 
                        adminPinInput = ""
                        adminPinError = false
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AdminPanelSettings, 
                                contentDescription = null, 
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Admin Verification", fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "This area is restricted to store owners for managing inventory and price configurations.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            OutlinedTextField(
                                value = adminPinInput,
                                onValueChange = { 
                                    if (it.length <= 4) {
                                        adminPinInput = it
                                        adminPinError = false
                                    }
                                },
                                label = { Text("Enter 4-Digit Admin PIN") },
                                placeholder = { Text("••••") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                isError = adminPinError,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("admin_pin_input"),
                                supportingText = {
                                    if (adminPinError) {
                                        Text("Incorrect administrator passcode", color = MaterialTheme.colorScheme.error)
                                    } else {
                                        Text("Default PIN is 8804")
                                    }
                                }
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                val hashedPin = com.example.data.SecurityCryptoUtils.sha256(adminPinInput)
                                if (hashedPin == "f74d0f06bb85ee535cdd81664c1fdf582eb8f752a083e69c8351fed904afee06") {
                                    showAdminLoginDialog = false
                                    adminPinInput = ""
                                    adminPinError = false
                                    onNavigateToAdmin()
                                } else {
                                    adminPinError = true
                                }
                            },
                            modifier = Modifier.testTag("submit_pin_button")
                        ) {
                            Text("Authorize")
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = { 
                                showAdminLoginDialog = false 
                                adminPinInput = ""
                                adminPinError = false
                            }
                        ) {
                            Text("Cancel")
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                    containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.95f)
                )
            }
        }
    }
}

@Composable
fun ProductGridItem(
    product: Product,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onProductClick)
            .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.45f, borderOpacity = 0.5f)
            .testTag("product_item_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column {
            // Drawn Furniture Illustration Thumbnail
            FurnitureDrawThumbnail(
                category = product.category,
                placeholderColor = product.imagePlaceholderColor,
                imageUrl = product.imageUrl,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            )

            Column(modifier = Modifier.padding(12.dp)) {
                // Category Tag
                Text(
                    text = product.category.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                )
                
                Spacer(modifier = Modifier.height(2.dp))

                // Name
                Text(
                    text = product.name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Rating & Stock status line
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = String.format(Locale.US, "%.1f", product.rating),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }

                    // Stock availability
                    val stockText = when {
                        product.stock == 0 -> "Out of Stock"
                        product.stock <= 3 -> "Only ${product.stock} left"
                        else -> "In Stock"
                    }
                    val stockColor = when {
                        product.stock == 0 -> MaterialTheme.colorScheme.error
                        product.stock <= 3 -> MaterialTheme.colorScheme.tertiary
                        else -> Color(0xFF4CAF50)
                    }
                    Text(
                        text = stockText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = stockColor
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price and Add button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "₹${product.price}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    IconButton(
                        onClick = onAddToCart,
                        modifier = Modifier
                            .size(32.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                            .testTag("add_to_cart_${product.id}"),
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add to Cart", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}


// ==========================================
// 2. PRODUCT DETAIL SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(
    productId: Int,
    viewModel: FurnitureViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val product = products.find { it.id == productId }

    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Product not found.")
        }
        return
    }

    val isWishlisted by viewModel.isProductWishlisted(productId).collectAsStateWithLifecycle(initialValue = false)
    val reviews by viewModel.getProductReviews(productId).collectAsStateWithLifecycle(initialValue = emptyList())
    val supportConfig by viewModel.supportConfig.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Review Inputs
    var reviewRating by remember { mutableStateOf(5) }
    var reviewComment by remember { mutableStateOf("") }
    var reviewerName by remember { mutableStateOf("") }

    // Buy Quantity
    var buyQuantity by remember { mutableStateOf(1) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Product Details", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleWishlist(productId) },
                        modifier = Modifier.testTag("detail_wishlist_toggle")
                    ) {
                        Icon(
                            imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Toggle Wishlist",
                            tint = if (isWishlisted) Color.Red else MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        bottomBar = {
            // Purchase Action Bar (Frosted Glass floating panel)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.Transparent,
                tonalElevation = 0.dp,
                shadowElevation = 0.dp
            ) {
                Column(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.85f, borderOpacity = 0.6f)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Quantity adjustments
                        Column {
                            Text("Quantity", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                IconButton(
                                    onClick = { if (buyQuantity > 1) buyQuantity-- },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                }
                                Text(
                                    text = buyQuantity.toString(),
                                    modifier = Modifier.padding(horizontal = 12.dp),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                IconButton(
                                    onClick = { if (buyQuantity < product.stock) buyQuantity++ },
                                    modifier = Modifier.size(28.dp),
                                    enabled = buyQuantity < product.stock
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Add to Cart Button with total price calculated
                        val totalPrice = product.price * buyQuantity
                        Button(
                            onClick = {
                                viewModel.addToCart(productId, buyQuantity)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("detail_add_to_cart"),
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            enabled = product.stock > 0
                        ) {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (product.stock > 0) "Add to Cart (₹${String.format(Locale.US, "%.2f", totalPrice)})" else "Out of Stock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Direct WhatsApp order booking button
                    val totalPrice = product.price * buyQuantity
                    Button(
                        onClick = {
                            val cleanNumber = supportConfig.whatsappNumber.replace("+", "").replace(" ", "").trim()
                            val message = """
                                Hello! I would like to book this furniture:
                                
                                *Product:* ${product.name}
                                *Category:* ${product.category}
                                *Price:* ₹${String.format(Locale.US, "%.2f", product.price)}
                                *Quantity:* $buyQuantity
                                *Material:* ${product.material}
                                *Dimensions:* ${product.dimensions}
                                
                                Please confirm my order and share delivery details!
                            """.trimIndent()
                            val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${android.net.Uri.encode(message)}"
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = android.net.Uri.parse(url)
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "WhatsApp is not installed on this device.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("detail_order_whatsapp"),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp Green
                        enabled = product.stock > 0
                    ) {
                        Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Order Directly on WhatsApp",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground()
                .verticalScroll(rememberScrollState())
        ) {
            // Large Thumbnail Showcase
            FurnitureDrawThumbnail(
                category = product.category,
                placeholderColor = product.imagePlaceholderColor,
                imageUrl = product.imageUrl,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .padding(16.dp)
            )

            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                // Header Details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(0.7f)) {
                        Text(
                            text = product.name,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.category.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(0.3f)
                    ) {
                        Text(
                            text = "₹${product.price}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        // Star Rating Display
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format(Locale.US, "%.1f", product.rating),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dimensions & Material specification cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("DIMENSIONS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(product.dimensions, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        }
                    }
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("MATERIAL", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(product.material, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Rich Story Description
                Text("CRAFTSMANSHIP STORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = product.description,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(16.dp))
                SocialShareSection(product = product)

                Spacer(modifier = Modifier.height(24.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(16.dp))

                // Reviews Section
                Text("CUSTOMER REVIEWS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(12.dp))

                // Write a Review Form block
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Add Your Review", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Star selector
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text("Your Rating: ", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Row {
                                (1..5).forEach { star ->
                                    val active = star <= reviewRating
                                    Icon(
                                        imageVector = if (active) Icons.Default.Star else Icons.Default.StarOutline,
                                        contentDescription = null,
                                        tint = if (active) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clickable { reviewRating = star }
                                            .testTag("star_select_$star")
                                    )
                                }
                            }
                        }

                        // Name input
                        OutlinedTextField(
                            value = reviewerName,
                            onValueChange = { reviewerName = it },
                            placeholder = { Text("Your name") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("review_name_input"),
                            singleLine = true
                        )

                        // Comment input
                        OutlinedTextField(
                            value = reviewComment,
                            onValueChange = { reviewComment = it },
                            placeholder = { Text("Write your review comment...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("review_comment_input"),
                            minLines = 2
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (reviewerName.isNotBlank() && reviewComment.isNotBlank()) {
                                    viewModel.addProductReview(
                                        productId = productId,
                                        userName = reviewerName.trim(),
                                        rating = reviewRating,
                                        comment = reviewComment.trim()
                                    )
                                    // Reset form inputs
                                    reviewerName = ""
                                    reviewComment = ""
                                    reviewRating = 5
                                }
                            },
                            modifier = Modifier
                                .align(Alignment.End)
                                .testTag("submit_review_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            enabled = reviewerName.isNotBlank() && reviewComment.isNotBlank()
                        ) {
                            Text("Post Review", fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Review items listing
                if (reviews.isEmpty()) {
                    Text(
                        "No reviews yet. Be the first to review this piece!",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        modifier = Modifier.padding(vertical = 16.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    reviews.forEach { r ->
                        ReviewItemRow(review = r)
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun SocialShareSection(product: Product, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var showPreviewDialog by remember { mutableStateOf<String?>(null) } // "Facebook", "Twitter", "Pinterest"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SHARE THIS MASTERPIECE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Facebook Share button
                SharePlatformButton(
                    name = "Facebook",
                    color = Color(0xFF1877F2),
                    icon = Icons.Default.Public,
                    onClick = { showPreviewDialog = "Facebook" }
                )
                
                // Twitter / X button
                SharePlatformButton(
                    name = "Twitter",
                    color = Color(0xFF1DA1F2),
                    icon = Icons.Default.Send,
                    onClick = { showPreviewDialog = "Twitter" }
                )
                
                // Pinterest button
                SharePlatformButton(
                    name = "Pinterest",
                    color = Color(0xFFBD081C),
                    icon = Icons.Default.Favorite,
                    onClick = { showPreviewDialog = "Pinterest" }
                )

                // More options
                SharePlatformButton(
                    name = "System",
                    color = MaterialTheme.colorScheme.primary,
                    icon = Icons.Default.Share,
                    onClick = {
                        val shareIntent = android.content.Intent().apply {
                            action = android.content.Intent.ACTION_SEND
                            putExtra(android.content.Intent.EXTRA_SUBJECT, product.name)
                            putExtra(
                                android.content.Intent.EXTRA_TEXT,
                                "Check out this beautiful ${product.name} on FurnitureKart!\n" +
                                "Price: ₹${product.price}\n" +
                                "Material: ${product.material}\n" +
                                "Description: ${product.description}\n\n" +
                                "View and purchase: https://furniturekart.com/products/${product.id}"
                            )
                            type = "text/plain"
                        }
                        context.startActivity(android.content.Intent.createChooser(shareIntent, "Share product via"))
                    }
                )
            }
        }
    }

    // Show platform-specific preview dialog for rich sharing!
    if (showPreviewDialog != null) {
        val platform = showPreviewDialog!!
        AlertDialog(
            onDismissRequest = { showPreviewDialog = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when(platform) {
                            "Facebook" -> Icons.Default.Public
                            "Twitter" -> Icons.Default.Send
                            else -> Icons.Default.Favorite
                        },
                        contentDescription = null,
                        tint = when(platform) {
                            "Facebook" -> Color(0xFF1877F2)
                            "Twitter" -> Color(0xFF1DA1F2)
                            else -> Color(0xFFBD081C)
                        },
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share to $platform", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column {
                    Text(
                        "Post Preview:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                    ) {
                        Column {
                            FurnitureDrawThumbnail(
                                category = product.category,
                                placeholderColor = product.imagePlaceholderColor,
                                imageUrl = product.imageUrl,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                            )
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "furniturekart.com/products/${product.id}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = product.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = product.description,
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "Shared link automatically includes high-resolution item render, dimensions (${product.dimensions}), and specifications.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val shareUrl = when(platform) {
                            "Facebook" -> "https://www.facebook.com/sharer/sharer.php?u=https://furniturekart.com/products/${product.id}&quote=Check%20out%20${product.name}%20on%20FurnitureKart!"
                            "Twitter" -> "https://twitter.com/intent/tweet?text=Check%20out%20${product.name}%20on%20FurnitureKart!%20${product.description}&url=https://furniturekart.com/products/${product.id}"
                            else -> "https://pinterest.com/pin/create/button/?url=https://furniturekart.com/products/${product.id}&description=${product.name}%20-%20${product.description}"
                        }
                        try {
                            val browserIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(shareUrl))
                            context.startActivity(browserIntent)
                        } catch (e: Exception) {
                            val fallbackIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(android.content.Intent.EXTRA_TEXT, "Check out ${product.name} on FurnitureKart! https://furniturekart.com/products/${product.id}")
                                type = "text/plain"
                            }
                            context.startActivity(android.content.Intent.createChooser(fallbackIntent, "Share product via"))
                        }
                        showPreviewDialog = null
                    },
                    modifier = Modifier.testTag("post_share_confirm_$platform")
                ) {
                    Text("Post to $platform")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPreviewDialog = null }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(28.dp),
            containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.95f)
        )
    }
}

@Composable
fun SharePlatformButton(
    name: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
            .testTag("share_btn_$name")
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(color.copy(alpha = 0.15f), CircleShape)
                .border(1.dp, color.copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = "Share via $name",
                tint = color,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = name,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun ReviewItemRow(review: Review, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.35f, borderOpacity = 0.3f),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(review.userName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                // Rating stars
                Row {
                    (1..5).forEach { star ->
                        Icon(
                            imageVector = if (star <= review.rating) Icons.Default.Star else Icons.Default.StarOutline,
                            contentDescription = null,
                            tint = if (star <= review.rating) Color(0xFFFFB300) else Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = review.comment,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )
            Spacer(modifier = Modifier.height(6.dp))
            val sdf = remember { SimpleDateFormat("MMM d, yyyy", Locale.US) }
            Text(
                text = sdf.format(Date(review.timestamp)),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
        }
    }
}


// ==========================================
// 3. CART AND SECURE CHECKOUT SCREENS
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    viewModel: FurnitureViewModel,
    onNavigateToCheckout: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cartWithProducts by viewModel.cartWithProductList.collectAsStateWithLifecycle()
    val subtotal by viewModel.cartSubtotal.collectAsStateWithLifecycle()
    val deliveryFee = if (cartWithProducts.isEmpty()) 0.0 else 15.0
    val totalAmount = subtotal + deliveryFee

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Your Cart", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("cart_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        bottomBar = {
            if (cartWithProducts.isNotEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.Transparent,
                    tonalElevation = 0.dp,
                    shadowElevation = 0.dp
                ) {
                    Column(
                        modifier = Modifier
                            .navigationBarsPadding()
                            .padding(16.dp)
                            .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.85f, borderOpacity = 0.6f)
                            .padding(16.dp)
                    ) {
                        // Calculations summary
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Text("₹${String.format(Locale.US, "%.2f", subtotal)}", fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Flat Shipping Delivery", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Text("₹${String.format(Locale.US, "%.2f", deliveryFee)}", fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Estimated Total", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "₹${String.format(Locale.US, "%.2f", totalAmount)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onNavigateToCheckout,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("proceed_checkout_button"),
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Proceed to Secure Checkout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        if (cartWithProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .glassBackground(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(
                        Icons.Default.ShoppingBag,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.15f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "Your shopping cart is empty",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Explore our unique hand-crafted collections to find the perfect furniture for your dream home layout.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onNavigateBack,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Start Shopping")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .glassBackground(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(cartWithProducts, key = { it.cartItem.id }) { item ->
                    CartItemRow(
                        item = item,
                        onIncrease = { viewModel.updateCartItemQuantity(item.cartItem.id, item.cartItem.quantity + 1) },
                        onDecrease = { viewModel.updateCartItemQuantity(item.cartItem.id, item.cartItem.quantity - 1) },
                        onRemove = { viewModel.removeFromCart(item.cartItem.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItemWithProduct,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .frostedGlass(shape = RoundedCornerShape(20.dp), lightOpacity = 0.45f, borderOpacity = 0.4f)
            .testTag("cart_item_${item.cartItem.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FurnitureDrawThumbnail(
                category = item.product.category,
                placeholderColor = item.product.imagePlaceholderColor,
                imageUrl = item.product.imageUrl,
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(8.dp))
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.product.category,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "₹${item.product.price}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action counts controls
            Column(horizontalAlignment = Alignment.End) {
                IconButton(onClick = onRemove, modifier = Modifier.size(28.dp).testTag("cart_remove_${item.cartItem.id}")) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(onClick = onDecrease, modifier = Modifier.size(24.dp).testTag("cart_decrease_${item.cartItem.id}")) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(12.dp))
                    }
                    Text(
                        text = item.cartItem.quantity.toString(),
                        modifier = Modifier.padding(horizontal = 8.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    IconButton(
                        onClick = onIncrease,
                        modifier = Modifier.size(24.dp).testTag("cart_increase_${item.cartItem.id}"),
                        enabled = item.cartItem.quantity < item.product.stock
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(12.dp))
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    viewModel: FurnitureViewModel,
    onNavigateToTracking: (Int) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cartWithProducts by viewModel.cartWithProductList.collectAsStateWithLifecycle()
    val subtotal by viewModel.cartSubtotal.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val checkoutState by viewModel.checkoutState.collectAsStateWithLifecycle()
    val supportConfig by viewModel.supportConfig.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val deliveryFee = 15.0
    val grandTotal = subtotal + deliveryFee

    // Form states
    val bankConfig by viewModel.bankConfig.collectAsStateWithLifecycle()
    val savedAddressesList = remember(userProfile) {
        userProfile?.savedAddresses?.split(";")?.filter { it.isNotBlank() } ?: emptyList()
    }
    var selectedAddress by remember(savedAddressesList) {
        mutableStateOf(savedAddressesList.firstOrNull() ?: "")
    }

    var showNewAddressBox by remember { mutableStateOf(false) }
    var newAddressInput by remember { mutableStateOf("") }

    // Payment details
    var paymentMethodType by remember { mutableStateOf("CARD") } // "CARD" or "UPI"
    var upiIdInput by remember { mutableStateOf("") }
    var upiTransactionRef by remember { mutableStateOf("") }

    var cardName by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }
    var isCardVisible by remember { mutableStateOf(false) }

    // Trigger redirection on checkout success
    LaunchedEffect(checkoutState) {
        if (checkoutState is CheckoutUiState.Success) {
            val orderId = (checkoutState as CheckoutUiState.Success).orderId
            
            // Construct WhatsApp Message
            val profile = userProfile
            val custName = profile?.name ?: "Valued Customer"
            val custPhone = profile?.phone ?: ""
            val custEmail = profile?.email ?: ""
            val itemsStr = cartWithProducts.joinToString("\n") { 
                "- ${it.product.name} x${it.cartItem.quantity} (₹${String.format(Locale.US, "%.2f", it.product.price * it.cartItem.quantity)})" 
            }
            
            val message = """
                Hello! I have placed an order on FurnitureKart:
                
                *Order ID:* #FKT-$orderId
                *Customer Name:* $custName
                *Phone:* $custPhone
                *Email:* $custEmail
                *Delivery Address:* $selectedAddress
                
                *Items Ordered:*
                $itemsStr
                
                *Subtotal:* ₹${String.format(Locale.US, "%.2f", subtotal)}
                *Delivery Fee:* ₹15.00
                *Grand Total:* ₹${String.format(Locale.US, "%.2f", grandTotal)}
                
                Please confirm my order. Thank you!
            """.trimIndent()
            
            val cleanNumber = supportConfig.whatsappNumber.replace("+", "").replace(" ", "").trim()
            val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${android.net.Uri.encode(message)}"
            
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    data = android.net.Uri.parse(url)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "WhatsApp is not installed on this device.", android.widget.Toast.LENGTH_SHORT).show()
            }
            
            viewModel.resetCheckoutState()
            onNavigateToTracking(orderId)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Secure Checkout", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("checkout_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground()
        ) {
            if (checkoutState is CheckoutUiState.ProcessingPayment) {
                // Bank HANDSHAKE HANDLER LOADER Visual
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.padding(32.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(48.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Authorizing Bank Transaction...", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "Establishing secure 256-bit SSL encrypted tunnel. Please do not close the app.",
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 8.dp),
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // SSL security Badge
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "256-Bit Bank-Level Payment Protection SSL Enabled",
                            color = Color(0xFF2E7D32),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Error feedback
                if (checkoutState is CheckoutUiState.PaymentError) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Text(
                            text = (checkoutState as CheckoutUiState.PaymentError).errorMessage,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // 1. DELIVERY ADDRESS SELECTOR
                Text("1. CHOOSE DELIVERY ADDRESS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))

                if (savedAddressesList.isEmpty() && !showNewAddressBox) {
                    showNewAddressBox = true
                }

                savedAddressesList.forEach { address ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (selectedAddress == address) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                else Color.Transparent
                            )
                            .clickable { selectedAddress = address }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (selectedAddress == address),
                            onClick = { selectedAddress = address },
                            modifier = Modifier.testTag("address_radio_${savedAddressesList.indexOf(address)}")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = address,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                if (!showNewAddressBox) {
                    OutlinedButton(
                        onClick = { showNewAddressBox = true },
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .testTag("show_add_address_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.AddLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ship to a different address", fontSize = 12.sp)
                    }
                } else {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .frostedGlass(shape = RoundedCornerShape(20.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Add Custom Delivery Address", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newAddressInput,
                                onValueChange = { newAddressInput = it },
                                placeholder = { Text("Full Address: Street, Apartment, City, Zip") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("new_address_input"),
                                minLines = 2
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { showNewAddressBox = false }) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (newAddressInput.isNotBlank()) {
                                            viewModel.addNewAddress(newAddressInput.trim())
                                            selectedAddress = newAddressInput.trim()
                                            newAddressInput = ""
                                            showNewAddressBox = false
                                        }
                                    },
                                    enabled = newAddressInput.isNotBlank(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.testTag("save_address_button")
                                ) {
                                    Text("Save address")
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(24.dp))

                // 2. ORDER SUMMARY & BOOK ON WHATSAPP
                Text("2. ORDER SUMMARY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))

                // Order Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        cartWithProducts.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(0.7f)) {
                                    Text(
                                        text = item.product.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Qty: ${item.cartItem.quantity} · ${item.product.material}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "₹${String.format(Locale.US, "%.2f", item.product.price * item.cartItem.quantity)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(0.3f),
                                    textAlign = TextAlign.End
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Price details breakdown
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹${String.format(Locale.US, "%.2f", subtotal)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Delivery Fee", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("₹${String.format(Locale.US, "%.2f", deliveryFee)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Grand Total", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(
                                text = "₹${String.format(Locale.US, "%.2f", grandTotal)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // WhatsApp Booking Info Banner
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Launch,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(24.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                "Order Booking via WhatsApp",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF2E7D32)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Your order will be booked locally in the app, and you will be immediately redirected to WhatsApp to send your shipping details directly to the store owner's hotline.",
                                fontSize = 11.sp,
                                color = Color(0xFF1B5E20),
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Big checkout action button (WhatsApp Order Booking)
                Button(
                    onClick = {
                        viewModel.processCheckout(
                            shippingAddress = selectedAddress,
                            paymentMethod = "WhatsApp Booking",
                            cardNumber = "WHATSAPP_MOCK",
                            cvv = "000",
                            expiry = "00/00"
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pay_and_submit_button"),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp green!
                    enabled = selectedAddress.isNotBlank() && cartWithProducts.isNotEmpty()
                ) {
                    Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Book Order & Confirm on WhatsApp",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(48.dp))
            }
        }
    }
}


// ==========================================
// 4. ORDER TRACKING & REVENUE LOG SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    orderId: Int,
    viewModel: FurnitureViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val order = orders.find { it.id == orderId }
    val notificationsLogs by viewModel.notifications.collectAsStateWithLifecycle()

    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Order #$orderId not found.")
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Order Tracker", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("tracking_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.45f, borderOpacity = 0.45f),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Order ID: #FKT-$orderId", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        val badgeColor = when (order.status) {
                            "Delivered" -> Color(0xFF4CAF50)
                            "Shipped" -> Color(0xFF2196F3)
                            else -> MaterialTheme.colorScheme.primary
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(badgeColor)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = order.status.uppercase(),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ITEMS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(order.itemsSummary, fontSize = 13.sp, fontWeight = FontWeight.Medium)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("SHIPPED TO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(order.address, fontSize = 13.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("TOTAL CHARGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    val displayTotal = "₹${String.format(Locale.US, "%.2f", order.totalAmount)}"
                    Text("$displayTotal (Charged via ${order.paymentMethod})", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PIPELINE PROCESS VISUAL
            Text("DELIVERY TRACKING TIMELINE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))

            Column(modifier = Modifier.padding(start = 8.dp)) {
                val stages = listOf(
                    "Order Placed" to 0.15f,
                    "Production & Crafting" to 0.45f,
                    "Dispatched (In Transit)" to 0.75f,
                    "Delivered & Assembled" to 1.0f
                )

                stages.forEachIndexed { index, (stageName, targetProg) ->
                    val isPast = order.trackingProgress >= targetProg
                    val isCurrent = !isPast && (index == 0 || order.trackingProgress >= stages[index - 1].second)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isPast -> Color(0xFF4CAF50)
                                        isCurrent -> MaterialTheme.colorScheme.primary
                                        else -> Color.LightGray
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isPast) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color.White, CircleShape)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = stageName,
                                fontWeight = if (isPast || isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isPast || isCurrent) MaterialTheme.colorScheme.onBackground else Color.LightGray,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // Progress connecting pipeline line
                    if (index < stages.lastIndex) {
                        Box(
                            modifier = Modifier
                                .padding(start = 11.dp)
                                .width(2.dp)
                                .height(24.dp)
                                .background(
                                    if (order.trackingProgress > targetProg) Color(0xFF4CAF50) else Color.LightGray
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // PRODUCTION LOG TIMELINE
            Text("PRODUCTION & TRANSIT TIMELINE LOGS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            val logs = order.deliveryStatusLogs.split(";").filter { it.isNotBlank() }
            logs.reversed().forEach { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        Icons.Default.LocalShipping,
                        contentDescription = null,
                        modifier = Modifier
                            .size(16.dp)
                            .padding(top = 2.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = log, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // Real-Time Push Notification Logs History
            Text("PUSH NOTIFICATION DISPATCH HISTORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            val orderAlerts = notificationsLogs.filter { it.message.contains(orderId.toString()) }
            if (orderAlerts.isEmpty()) {
                Text(
                    "No system notifications triggered for this order yet.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                orderAlerts.forEach { alert ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.35f, borderOpacity = 0.35f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(alert.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                                Spacer(modifier = Modifier.height(4.dp))
                                val sdf = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }
                                Text(
                                    text = "Fired at ${sdf.format(Date(alert.timestamp))}",
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}


// ==========================================
// 5. USER PROFILE SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    viewModel: FurnitureViewModel,
    onNavigateToOrder: (Int) -> Unit,
    onNavigateToProduct: (Int) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val wishlist by viewModel.wishlistItems.collectAsStateWithLifecycle()
    val products by viewModel.allProducts.collectAsStateWithLifecycle()

    var isEditing by remember { mutableStateOf(false) }

    // Edit states
    var editName by remember(userProfile) { mutableStateOf(userProfile?.name ?: "") }
    var editEmail by remember(userProfile) { mutableStateOf(userProfile?.email ?: "") }
    var editPhone by remember(userProfile) { mutableStateOf(userProfile?.phone ?: "") }

    val savedAddresses = remember(userProfile) {
        userProfile?.savedAddresses?.split(";")?.filter { it.isNotBlank() } ?: emptyList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("profile_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // 1. PROFILE DETAILS CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.45f, borderOpacity = 0.45f),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Personal Credentials", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(
                            onClick = {
                                if (isEditing) {
                                    viewModel.updateProfile(editName, editEmail, editPhone, savedAddresses)
                                }
                                isEditing = !isEditing
                            },
                            modifier = Modifier.testTag("edit_profile_toggle")
                        ) {
                            Icon(
                                imageVector = if (isEditing) Icons.Default.Save else Icons.Default.Edit,
                                contentDescription = if (isEditing) "Save profile" else "Edit profile",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isEditing) {
                        Text("NAME", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(userProfile?.name ?: "Sarah Jenkins", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("EMAIL ADDRESS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(userProfile?.email ?: "sarah.jenkins@gmail.com", fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("CONTACT PHONE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(userProfile?.phone ?: "+1 (555) 432-8765", fontSize = 14.sp)
                    } else {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Full Name") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("edit_name_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editEmail,
                            onValueChange = { editEmail = it },
                            label = { Text("Email Address") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("edit_email_input"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editPhone,
                            onValueChange = { editPhone = it },
                            label = { Text("Phone Number") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("edit_phone_input"),
                            singleLine = true
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 2. SAVED DELIVERY ADDRESSES
            Text("SAVED DELIVERY ADDRESSES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            if (savedAddresses.isEmpty()) {
                Text("No addresses saved yet.", fontSize = 13.sp, color = Color.Gray)
            } else {
                savedAddresses.forEach { addr ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.35f, borderOpacity = 0.35f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = addr, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val listWithoutCurrent = savedAddresses.filter { it != addr }
                                viewModel.updateProfile(editName, editEmail, editPhone, listWithoutCurrent)
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete address", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // 3. ORDER HISTORY
            Text("ORDER HISTORIES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            if (orders.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .frostedGlass(shape = RoundedCornerShape(20.dp), lightOpacity = 0.35f, borderOpacity = 0.35f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No orders placed yet", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            } else {
                orders.forEach { order ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .frostedGlass(shape = RoundedCornerShape(20.dp), lightOpacity = 0.4f, borderOpacity = 0.4f)
                            .clickable { onNavigateToOrder(order.id) }
                            .testTag("order_history_item_${order.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(0.7f)) {
                                Text("Order #FKT-${order.id}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                val sdf = remember { SimpleDateFormat("MMM d, yyyy", Locale.US) }
                                Text(
                                    text = sdf.format(Date(order.orderDate)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = order.itemsSummary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.End,
                                modifier = Modifier.weight(0.3f)
                            ) {
                                Text(
                                    text = "₹${String.format(Locale.US, "%.2f", order.totalAmount)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when (order.status) {
                                                "Delivered" -> Color(0xFFE8F5E9)
                                                "Shipped" -> Color(0xFFE3F2FD)
                                                else -> MaterialTheme.colorScheme.primaryContainer
                                            }
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = order.status,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (order.status) {
                                            "Delivered" -> Color(0xFF2E7D32)
                                            "Shipped" -> Color(0xFF1565C0)
                                            else -> MaterialTheme.colorScheme.onPrimaryContainer
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // 4. MY WISHLIST
            Text("MY WISHLIST ITEMS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(12.dp))

            val wishlistedProducts = wishlist.mapNotNull { wItem ->
                products.find { it.id == wItem.productId }
            }

            if (wishlistedProducts.isEmpty()) {
                Text(
                    text = "Your wishlist is currently empty. Tap the heart button on products to save favorites.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 12.dp),
                    textAlign = TextAlign.Center
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .heightIn(max = 400.dp)
                        .testTag("wishlist_grid"),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(wishlistedProducts) { wProduct ->
                        ProductGridItem(
                            product = wProduct,
                            onProductClick = { onNavigateToProduct(wProduct.id) },
                            onAddToCart = { viewModel.addToCart(wProduct.id) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // 5. CUSTOMER SUPPORT (WHATSAPP HOTLINE)
            val supportConfig by viewModel.supportConfig.collectAsStateWithLifecycle()
            val localContext = LocalContext.current

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.45f, borderOpacity = 0.45f)
                    .testTag("customer_support_whatsapp_card"),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Call,
                            contentDescription = null,
                            tint = Color(0xFF25D366), // WhatsApp Green
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "24/7 CUSTOMER SUPPORT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Have questions about your furniture selection or need order assistance? Connect directly with our design consultants on WhatsApp.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            try {
                                val cleanNumber = supportConfig.whatsappNumber.replace("+", "").replace(" ", "").trim()
                                val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${android.net.Uri.encode(supportConfig.supportMessage)}"
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = android.net.Uri.parse(url)
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                localContext.startActivity(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(localContext, "WhatsApp is not installed on this device.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp Brand Color
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("launch_whatsapp_support_btn")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Chat on WhatsApp Support", 
                            fontWeight = FontWeight.Bold, 
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginGate(
    onNavigateBack: () -> Unit,
    onLoginSuccess: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf(false) }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var loginAttempts by remember { mutableStateOf(0) }
    var loginLockoutSeconds by remember { mutableStateOf(0) }

    LaunchedEffect(loginLockoutSeconds) {
        if (loginLockoutSeconds > 0) {
            kotlinx.coroutines.delay(1000)
            loginLockoutSeconds -= 1
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .glassBackground(),
        contentAlignment = Alignment.Center
    ) {
        // Elegant Back button to exit the admin panel
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .padding(top = 16.dp)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f), CircleShape)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Store",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Main login card
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                .frostedGlass(shape = RoundedCornerShape(28.dp), lightOpacity = 0.5f, borderOpacity = 0.5f),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Logo/Icon
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin Area",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Admin Portal",
                        fontWeight = FontWeight.Black,
                        fontSize = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Authorized Personnel Only",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Username Input
                OutlinedTextField(
                    value = username,
                    onValueChange = {
                        username = it
                        loginError = false
                    },
                    label = { Text("Admin Username") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_username_input")
                )

                // Password Input
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        loginError = false
                    },
                    label = { Text("Admin Password") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                        )
                    },
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    },
                    visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_password_input")
                )

                if (loginLockoutSeconds > 0) {
                    Text(
                        text = "Too many failed attempts. Locked out for $loginLockoutSeconds seconds.",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                } else if (loginError) {
                    Text(
                        text = "Invalid credentials. Please try again (${5 - loginAttempts} attempts remaining).",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    enabled = loginLockoutSeconds <= 0 && username.isNotBlank() && password.isNotBlank(),
                    onClick = {
                        if (loginLockoutSeconds > 0) return@Button
                        val hashedUser = com.example.data.SecurityCryptoUtils.sha256(username.trim())
                        val hashedPassword = com.example.data.SecurityCryptoUtils.sha256(password)
                        if (hashedUser == "3c7a42d53ab8d40ad23966d05f643c42b058b8c8d1594ba9d415477350260e8d" &&
                            hashedPassword == "f2ac68c94f16ebbb70599251eb34d0ebe2e25d304ee64183422c0f96cc9eab72") {
                            loginAttempts = 0
                            onLoginSuccess()
                        } else {
                            loginAttempts += 1
                            if (loginAttempts >= 5) {
                                loginLockoutSeconds = 30
                            }
                            loginError = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("admin_login_submit_btn"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.Login, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Secure Login",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}


// ==========================================
// 6. ADMIN DASHBOARD SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: FurnitureViewModel,
    onNavigateToOrderTracking: (Int) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products by viewModel.allProducts.collectAsStateWithLifecycle()
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()

    var isAdminLoggedIn by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }

    if (!isAdminLoggedIn) {
        AdminLoginGate(
            onNavigateBack = onNavigateBack,
            onLoginSuccess = { isAdminLoggedIn = true }
        )
        return
    }

    val smtpConfigFlow by viewModel.smtpConfig.collectAsStateWithLifecycle()
    
    // Email Settings Form States
    var emailEnabled by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.enabled) }
    var smtpHost by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.smtpHost) }
    var smtpPort by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.smtpPort) }
    var smtpUser by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.username) }
    var smtpPass by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.password) }
    var smtpRecipient by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.recipient) }
    var smtpUseSsl by remember(smtpConfigFlow) { mutableStateOf(smtpConfigFlow.useSsl) }
    
    var isSmtpPasswordVisible by remember { mutableStateOf(false) }
    var showEmailSettings by remember { mutableStateOf(false) }
    var testEmailResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) } // success, message
    var isSendingTestEmail by remember { mutableStateOf(false) }

    val bankConfigFlow by viewModel.bankConfig.collectAsStateWithLifecycle()

    // Bank Settings Form States
    var bankConnected by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.isConnected) }
    var bankName by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.bankName) }
    var bankAccountNum by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.accountNumber) }
    var bankIfsc by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.ifscCode) }
    var bankHolderName by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.accountHolderName) }
    var bankUpiId by remember(bankConfigFlow) { mutableStateOf(bankConfigFlow.upiId) }

    var showBankSettings by remember { mutableStateOf(false) }

    val supportConfigFlow by viewModel.supportConfig.collectAsStateWithLifecycle()
    var supportWhatsappNumber by remember(supportConfigFlow) { mutableStateOf(supportConfigFlow.whatsappNumber) }
    var supportMessageTemplate by remember(supportConfigFlow) { mutableStateOf(supportConfigFlow.supportMessage) }
    var showSupportSettings by remember { mutableStateOf(false) }

    var showAddForm by remember { mutableStateOf(false) }
    var showEditProductDialogProduct by remember { mutableStateOf<Product?>(null) }

    // Edit Form states
    var editProductName by remember { mutableStateOf("") }
    var editProductDesc by remember { mutableStateOf("") }
    var editProductPrice by remember { mutableStateOf("") }
    var editProductCategory by remember { mutableStateOf("Sofa") }
    var editProductStock by remember { mutableStateOf("") }
    var editProductMaterial by remember { mutableStateOf("Premium Wood") }
    var editProductDimens by remember { mutableStateOf("Standard dimensions") }
    var editProductColor by remember { mutableStateOf(0L) }
    var editProductImageUrl by remember { mutableStateOf("") }
    var editIsCustomCategory by remember { mutableStateOf(false) }
    var editCustomCategoryText by remember { mutableStateOf("") }

    // Add Form states
    var addName by remember { mutableStateOf("") }
    var addDesc by remember { mutableStateOf("") }
    var addPrice by remember { mutableStateOf("") }
    var addCategory by remember { mutableStateOf("Sofa") }
    var addStock by remember { mutableStateOf("") }
    var addMaterial by remember { mutableStateOf("Premium Wood") }
    var addDimens by remember { mutableStateOf("Standard dimensions") }
    var addImageUrl by remember { mutableStateOf("") }
    var isCustomCategory by remember { mutableStateOf(false) }
    var customCategoryText by remember { mutableStateOf("") }

    val categories = listOf("Sofa", "Chair", "Table", "Bed", "Decor", "Custom Type...")

    // Stats calculations
    val totalSales = orders.sumOf { it.totalAmount }
    val activeOrdersCount = orders.count { it.status != "Delivered" && it.status != "Cancelled" }
    val avgRating = if (products.isEmpty()) 4.5f else products.sumOf { it.rating.toDouble() }.toFloat() / products.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Store Control Panel", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("admin_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { isAdminLoggedIn = false },
                        modifier = Modifier.testTag("admin_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Log Out",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent)
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .glassBackground()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Analytics stats row
            Text("ANALYTICS SUMMARY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("REVENUE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("₹${String.format(Locale.US, "%.2f", totalSales)}", fontWeight = FontWeight.Black, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Card(
                    modifier = Modifier
                        .weight(1.5f)
                        .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ACTIVE JOBS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text("$activeOrdersCount orders", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
                Card(
                    modifier = Modifier
                        .weight(1.2f)
                        .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("AVG RATING", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(String.format(Locale.US, "%.1f ★", avgRating), fontWeight = FontWeight.Black, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            // Live Purchase Alerts Section for Store Owner
            val adminAlerts by viewModel.adminAlerts.collectAsStateWithLifecycle()
            
            if (adminAlerts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.NotificationsActive, 
                                    contentDescription = "Active Notifications", 
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "LIVE PURCHASE ALERTS", 
                                    fontWeight = FontWeight.Black, 
                                    fontSize = 11.sp, 
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            TextButton(
                                onClick = { viewModel.clearAdminAlerts() },
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.tertiary),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("Clear", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        adminAlerts.take(5).forEach { alert ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = alert.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = alert.message,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // ADD NEW PRODUCT MANAGER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("INVENTORY CATALOG OPERATIONS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                TextButton(
                    onClick = { showAddForm = !showAddForm },
                    modifier = Modifier.testTag("toggle_add_product")
                ) {
                    Text(if (showAddForm) "Close Form" else "+ List New Item", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            AnimatedVisibility(
                visible = showAddForm,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Add New Furniture Item", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = addName,
                            onValueChange = { addName = it },
                            label = { Text("Furniture Item Name") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_add_name"),
                            singleLine = true
                        )

                        // Category Dropdown
                        var expandedCatMenu by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.padding(vertical = 4.dp)) {
                            OutlinedTextField(
                                value = addCategory,
                                onValueChange = {},
                                label = { Text("Category Selection") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = { expandedCatMenu = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expandedCatMenu = true }
                                    .testTag("admin_add_category_field")
                            )
                            DropdownMenu(
                                expanded = expandedCatMenu,
                                onDismissRequest = { expandedCatMenu = false }
                            ) {
                                categories.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat) },
                                        onClick = {
                                            addCategory = cat
                                            expandedCatMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        if (addCategory == "Custom Type...") {
                            OutlinedTextField(
                                value = customCategoryText,
                                onValueChange = { customCategoryText = it },
                                label = { Text("Specify Custom Furniture Type") },
                                placeholder = { Text("e.g. Wardrobe, Cabinet, Desk") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("admin_add_custom_category_input"),
                                singleLine = true
                            )
                        }

                        // Price and Stock
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = addPrice,
                                onValueChange = { addPrice = it },
                                label = { Text("Price ($)") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_add_price"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = addStock,
                                onValueChange = { addStock = it },
                                label = { Text("Initial Stock") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_add_stock"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        // Material & Dimensions
                        OutlinedTextField(
                            value = addDimens,
                            onValueChange = { addDimens = it },
                            label = { Text("Dimensions Size") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_add_dimensions"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = addMaterial,
                            onValueChange = { addMaterial = it },
                            label = { Text("Craft Material") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_add_material"),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val galleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                                contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
                            ) { uri: android.net.Uri? ->
                                uri?.let { addImageUrl = it.toString() }
                            }

                            OutlinedTextField(
                                value = addImageUrl,
                                onValueChange = { addImageUrl = it },
                                label = { Text("Product Picture (URL or Gallery)") },
                                placeholder = { Text("https://example.com/image.jpg") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_add_image_url"),
                                singleLine = true
                            )

                            IconButton(
                                onClick = { galleryLauncher.launch("image/*") },
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .size(48.dp)
                                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = "Choose from Gallery", tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // Presets Selector Row
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("OR SELECT A STUNNING STOCK PHOTO:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(2.dp))
                        val presetImages = listOf(
                            "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80&w=600" to "Emerald Sofa",
                            "https://images.unsplash.com/photo-1484101403633-562f891dc89a?auto=format&fit=crop&q=80&w=600" to "Cream Sofa",
                            "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&q=80&w=600" to "Ash Lounge",
                            "https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&q=80&w=600" to "Wood Chair",
                            "https://images.unsplash.com/photo-1577140917170-285929fb55b7?auto=format&fit=crop&q=80&w=600" to "Oak Table",
                            "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&q=80&w=600" to "Desk Office",
                            "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&q=80&w=600" to "Cozy Bed",
                            "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&q=80&w=600" to "Table Lamp",
                            "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&q=80&w=600" to "Nordic Art"
                        )
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            items(presetImages) { (url, label) ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (addImageUrl == url) MaterialTheme.colorScheme.primaryContainer 
                                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        )
                                        .border(
                                            1.dp, 
                                            if (addImageUrl == url) MaterialTheme.colorScheme.primary 
                                            else Color.Transparent, 
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { addImageUrl = url }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = addDesc,
                            onValueChange = { addDesc = it },
                            label = { Text("Item Description story") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_add_desc"),
                            minLines = 2
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val priceVal = addPrice.toDoubleOrNull()
                                val stockVal = addStock.toIntOrNull()
                                val finalCategory = if (addCategory == "Custom Type...") {
                                    if (customCategoryText.isNotBlank()) customCategoryText.trim() else "Other"
                                } else addCategory

                                if (addName.isNotBlank() && priceVal != null && stockVal != null && addDesc.isNotBlank()) {
                                    viewModel.adminAddNewProduct(
                                        name = addName.trim(),
                                        description = addDesc.trim(),
                                        price = priceVal,
                                        category = finalCategory,
                                        stock = stockVal,
                                        material = addMaterial.trim(),
                                        dimensions = addDimens.trim(),
                                        imageUrl = addImageUrl.trim()
                                    )
                                    // Reset inputs
                                    addName = ""
                                    addDesc = ""
                                    addPrice = ""
                                    addStock = ""
                                    addImageUrl = ""
                                    customCategoryText = ""
                                    addCategory = "Sofa"
                                    showAddForm = false
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_submit_product"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            enabled = addName.isNotBlank() && addPrice.toDoubleOrNull() != null && addStock.toIntOrNull() != null
                        ) {
                            Text("Publish to Catalog", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Products List with inline Stock Adjuster
            products.forEach { p ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .frostedGlass(shape = RoundedCornerShape(16.dp), lightOpacity = 0.35f, borderOpacity = 0.35f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FurnitureDrawThumbnail(
                            category = p.category,
                            placeholderColor = p.imagePlaceholderColor,
                            imageUrl = p.imageUrl,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Category: ${p.category} | Price: ₹${String.format(Locale.US, "%.2f", p.price)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        showEditProductDialogProduct = p
                                        editProductName = p.name
                                        editProductDesc = p.description
                                        editProductPrice = p.price.toString()
                                        editProductCategory = p.category
                                        editProductStock = p.stock.toString()
                                        editProductMaterial = p.material
                                        editProductDimens = p.dimensions
                                        editProductColor = p.imagePlaceholderColor
                                        editProductImageUrl = p.imageUrl
                                    },
                                    modifier = Modifier.size(24.dp).testTag("edit_product_btn_${p.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Product Details",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            // Stock counter adjuster
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Stock: ", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    IconButton(
                                        onClick = { if (p.stock > 0) viewModel.adminUpdateProductStock(p.id, p.stock - 1) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease Stock", modifier = Modifier.size(10.dp))
                                    }
                                    Text(
                                        text = p.stock.toString(),
                                        modifier = Modifier.padding(horizontal = 6.dp),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    IconButton(
                                        onClick = { viewModel.adminUpdateProductStock(p.id, p.stock + 1) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase Stock", modifier = Modifier.size(10.dp))
                                    }
                                }
                            }
                        }

                        IconButton(
                            onClick = { viewModel.adminDeleteProduct(p.id) },
                            modifier = Modifier.testTag("admin_delete_product_${p.id}")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // ACTIVE ORDERS FULFILLMENT LIST
            Text("ORDER FULFILLMENT TRACKER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            if (orders.isEmpty()) {
                Text("No client orders placed yet.", fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 12.dp))
            } else {
                orders.forEach { order ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .frostedGlass(shape = RoundedCornerShape(20.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Order #FKT-${order.id}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Customer Address: ${order.address}", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                
                                // Current Status indicator badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(order.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Items summary: ${order.itemsSummary}", fontSize = 12.sp)
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "CUSTOMER DETAILS",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Name: ${order.customerName.ifBlank { "Guest User" }}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Email: ${order.customerEmail.ifBlank { "Not provided" }}",
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "Phone: ${order.customerPhone.ifBlank { "Not provided" }}",
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { onNavigateToOrderTracking(order.id) },
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("View Live Timeline", fontSize = 11.sp)
                                }

                                if (order.status != "Delivered") {
                                    Button(
                                        onClick = { viewModel.adminAdvanceOrderStatus(order.id) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        modifier = Modifier
                                            .height(32.dp)
                                            .testTag("admin_advance_order_${order.id}")
                                    ) {
                                        Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = when (order.status) {
                                                "Pending" -> "Approve order"
                                                "Processing" -> "Ship Out (Transit)"
                                                "Shipped" -> "Confirm delivery"
                                                else -> "Complete order"
                                            },
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Fulfillment Completed", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF4CAF50))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(24.dp))

            // AUTOMATED EMAIL NOTIFICATION SYSTEM PANEL
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Email, 
                        contentDescription = "Email Alerts", 
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "AUTOMATED EMAIL NOTIFICATIONS", 
                        fontSize = 12.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                TextButton(
                    onClick = { showEmailSettings = !showEmailSettings },
                    modifier = Modifier.testTag("toggle_email_settings")
                ) {
                    Text(if (showEmailSettings) "Hide Controls" else "Configure SMTP", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            AnimatedVisibility(
                visible = showEmailSettings,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    val context = LocalContext.current
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "SMTP Mail Server Configuration", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Alerts the administrator via email instantly whenever a new checkout is successfully completed.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Toggle switch for Enabled state
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Enable Automated Alerts", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(
                                    "When active, purchase receipts are sent automatically.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            Switch(
                                checked = emailEnabled,
                                onCheckedChange = { emailEnabled = it },
                                modifier = Modifier.testTag("email_alerts_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = smtpRecipient,
                            onValueChange = { smtpRecipient = it },
                            label = { Text("Admin Recipient Email") },
                            placeholder = { Text("e.g. samyzzsecret@gmail.com") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("email_recipient_input"),
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = smtpHost,
                                onValueChange = { smtpHost = it },
                                label = { Text("SMTP Server Host") },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .padding(vertical = 4.dp)
                                    .testTag("email_host_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = smtpPort,
                                onValueChange = { smtpPort = it },
                                label = { Text("Port") },
                                modifier = Modifier
                                    .weight(0.8f)
                                    .padding(vertical = 4.dp)
                                    .testTag("email_port_input"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }

                        OutlinedTextField(
                            value = smtpUser,
                            onValueChange = { smtpUser = it },
                            label = { Text("Sender Email (Username)") },
                            placeholder = { Text("e.g. storeowner@gmail.com") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("email_sender_user_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = smtpPass,
                            onValueChange = { smtpPass = it },
                            label = { Text("Sender App Password") },
                            placeholder = { Text("Enter SMTP password") },
                            visualTransformation = if (isSmtpPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { isSmtpPasswordVisible = !isSmtpPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isSmtpPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle password visibility"
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("email_sender_pass_input"),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.Checkbox(
                                checked = smtpUseSsl,
                                onCheckedChange = { smtpUseSsl = it ?: false },
                                modifier = Modifier.testTag("email_use_ssl_checkbox")
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Use SSL (Recommended for port 465; Uncheck for port 587 TLS)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                            )
                        }

                        // Informational box for Gmail configuration
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    Icons.Default.Info, 
                                    contentDescription = "Gmail Guide", 
                                    tint = MaterialTheme.colorScheme.primary, 
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "Tip: For Gmail, use host 'smtp.gmail.com', port '587', and generate a 16-character 'App Password' from your Google Account settings rather than using your main account password.",
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        // Test email execution indicator
                        testEmailResult?.let { result ->
                            val success = result.first
                            val msg = result.second
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (success) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (success) Icons.Default.CheckCircle else Icons.Default.Info,
                                        contentDescription = null,
                                        tint = if (success) Color(0xFF2E7D32) else Color(0xFFC62828),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = msg,
                                        color = if (success) Color(0xFF2E7D32) else Color(0xFFC62828),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Control Buttons (Save and Test)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Test Email Button
                            OutlinedButton(
                                onClick = {
                                    isSendingTestEmail = true
                                    testEmailResult = null
                                    val testConfig = com.example.data.SmtpConfig(
                                        enabled = emailEnabled,
                                        smtpHost = smtpHost,
                                        smtpPort = smtpPort,
                                        username = smtpUser,
                                        password = smtpPass,
                                        recipient = smtpRecipient,
                                        useSsl = smtpUseSsl
                                    )
                                    viewModel.sendTestEmail(testConfig) { success, message ->
                                        isSendingTestEmail = false
                                        testEmailResult = Pair(success, message)
                                    }
                                },
                                enabled = !isSendingTestEmail && smtpUser.isNotBlank() && smtpPass.isNotBlank() && smtpRecipient.isNotBlank(),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("email_test_button")
                            ) {
                                if (isSendingTestEmail) {
                                    androidx.compose.material3.CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sending...", fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Send Test", fontSize = 12.sp)
                                }
                            }

                            // Save Configuration Button
                            Button(
                                onClick = {
                                    val newConfig = com.example.data.SmtpConfig(
                                        enabled = emailEnabled,
                                        smtpHost = smtpHost,
                                        smtpPort = smtpPort,
                                        username = smtpUser,
                                        password = smtpPass,
                                        recipient = smtpRecipient,
                                        useSsl = smtpUseSsl
                                    )
                                    viewModel.updateSmtpConfig(newConfig)
                                    android.widget.Toast.makeText(context, "SMTP configuration saved successfully!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("email_save_button")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save Settings", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))

            // CLOUD SYNC CONFIGURATION PANEL
            val syncConfigFlow by viewModel.cloudSyncConfig.collectAsStateWithLifecycle()
            val isSyncingAdmin by viewModel.isSyncing.collectAsStateWithLifecycle()
            val syncMessageAdmin by viewModel.syncMessage.collectAsStateWithLifecycle()
            val contextAdmin = LocalContext.current

            var syncChannelId by remember(syncConfigFlow) { mutableStateOf(syncConfigFlow.channelId) }
            var syncAutoPush by remember(syncConfigFlow) { mutableStateOf(syncConfigFlow.autoPush) }
            var syncAutoPull by remember(syncConfigFlow) { mutableStateOf(syncConfigFlow.autoPull) }
            var showSyncSettings by remember { mutableStateOf(false) }

            LaunchedEffect(syncMessageAdmin) {
                syncMessageAdmin?.let {
                    android.widget.Toast.makeText(contextAdmin, it, android.widget.Toast.LENGTH_LONG).show()
                    viewModel.clearSyncMessage()
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CloudSync, 
                        contentDescription = "Cloud Sync", 
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "CLOUD STORE CATALOG SYNC", 
                        fontSize = 12.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                TextButton(
                    onClick = { showSyncSettings = !showSyncSettings },
                    modifier = Modifier.testTag("toggle_sync_settings")
                ) {
                    Text(if (showSyncSettings) "Hide Controls" else "Configure Sync", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            AnimatedVisibility(
                visible = showSyncSettings,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Cloud Catalog Sync Settings", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Connect multiple installations of FurnitureKart to the same cloud store so all users immediately see your newly added or updated products.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = syncChannelId,
                            onValueChange = { syncChannelId = it },
                            label = { Text("Cloud Store Channel ID (Passcode)") },
                            placeholder = { Text("e.g. global_furniture_store") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("sync_channel_id_input"),
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Key, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        )

                        // Auto-push switch
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Push Updates to Cloud", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Instantly sync catalog when adding, editing, or deleting items.", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = syncAutoPush,
                                onCheckedChange = { syncAutoPush = it },
                                modifier = Modifier.testTag("sync_auto_push_switch")
                            )
                        }

                        // Auto-pull switch
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Pull Updates on Launch", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Automatically fetch the latest catalog when users open the app.", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = syncAutoPull,
                                onCheckedChange = { syncAutoPull = it },
                                modifier = Modifier.testTag("sync_auto_pull_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Actions: Save, Pull (Import), Push (Export)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Save Settings
                            Button(
                                onClick = {
                                    val newConfig = CloudSyncConfig(
                                        channelId = syncChannelId,
                                        autoPush = syncAutoPush,
                                        autoPull = syncAutoPull
                                    )
                                    viewModel.updateCloudSyncConfig(newConfig)
                                    android.widget.Toast.makeText(contextAdmin, "Sync configurations saved!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Save Settings", fontSize = 11.sp)
                            }

                            // Manual Push (Upload)
                            Button(
                                onClick = { viewModel.pushCatalogToCloud() },
                                enabled = !isSyncingAdmin,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Push to Cloud", fontSize = 11.sp)
                                }
                            }

                            // Manual Pull (Download)
                            OutlinedButton(
                                onClick = { viewModel.pullCatalogFromCloud() },
                                enabled = !isSyncingAdmin,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pull from Cloud", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))

            // SECURE BANK CONNECTION PORTAL
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AccountBalance, 
                        contentDescription = "Bank Connection", 
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "SECURE BANK CONNECTION", 
                        fontSize = 12.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                TextButton(
                    onClick = { showBankSettings = !showBankSettings },
                    modifier = Modifier.testTag("toggle_bank_settings")
                ) {
                    Text(if (showBankSettings) "Hide Controls" else "Configure Bank", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            AnimatedVisibility(
                visible = showBankSettings,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    val context = LocalContext.current
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Bank Account Link & UPI Node Setup", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Connect your professional bank account to process electronic transfers, receive customer sales, and direct checkout payments.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Connect / Disconnect Toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Bank Link Status", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(if (bankConnected) Color(0xFF4CAF50) else Color(0xFFFF5252))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        if (bankConnected) "Connected" else "Disconnected",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (bankConnected) Color(0xFF4CAF50) else Color(0xFFFF5252)
                                    )
                                }
                            }
                            Switch(
                                checked = bankConnected,
                                onCheckedChange = { bankConnected = it },
                                modifier = Modifier.testTag("bank_connect_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = bankHolderName,
                            onValueChange = { bankHolderName = it },
                            label = { Text("Account Holder Name") },
                            placeholder = { Text("e.g. Samyzz Enterprises") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("bank_holder_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = bankName,
                            onValueChange = { bankName = it },
                            label = { Text("Bank Name") },
                            placeholder = { Text("e.g. State Bank of India") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("bank_name_input"),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = bankAccountNum,
                                onValueChange = { bankAccountNum = it },
                                label = { Text("Account Number") },
                                placeholder = { Text("e.g. 987654321012") },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .padding(vertical = 4.dp)
                                    .testTag("bank_account_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = bankIfsc,
                                onValueChange = { bankIfsc = it },
                                label = { Text("IFSC / BIC Code") },
                                placeholder = { Text("SBIN0001234") },
                                modifier = Modifier
                                    .weight(0.8f)
                                    .padding(vertical = 4.dp)
                                    .testTag("bank_ifsc_input"),
                                singleLine = true
                            )
                        }

                        OutlinedTextField(
                            value = bankUpiId,
                            onValueChange = { bankUpiId = it },
                            label = { Text("Merchant UPI ID for Direct Checkout") },
                            placeholder = { Text("e.g. businessname@upi") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("bank_upi_merchant_input"),
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Payment, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Save Configuration Button
                        Button(
                            onClick = {
                                val newConfig = com.example.data.BankConfig(
                                    isConnected = bankConnected,
                                    bankName = bankName,
                                    accountNumber = bankAccountNum,
                                    ifscCode = bankIfsc,
                                    accountHolderName = bankHolderName,
                                    upiId = bankUpiId
                                )
                                viewModel.updateBankConfig(newConfig)
                                android.widget.Toast.makeText(context, "Bank connection settings saved successfully!", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            enabled = bankHolderName.isNotBlank() && bankAccountNum.isNotBlank() && bankIfsc.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("bank_save_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Bank Details", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(16.dp))

            // WHATSAPP SUPPORT CONTROL SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "CUSTOMER SUPPORT SETUP", 
                        fontSize = 12.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                TextButton(
                    onClick = { showSupportSettings = !showSupportSettings },
                    modifier = Modifier.testTag("toggle_support_settings")
                ) {
                    Text(if (showSupportSettings) "Hide Controls" else "Configure Support", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            AnimatedVisibility(
                visible = showSupportSettings,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.4f, borderOpacity = 0.4f),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    val context = LocalContext.current
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Official WhatsApp Hotline Connection", 
                            fontWeight = FontWeight.Bold, 
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Provide a WhatsApp Hotline number and support template message for customers to connect with you directly.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = supportWhatsappNumber,
                            onValueChange = { supportWhatsappNumber = it },
                            label = { Text("WhatsApp Hotline (with Country Code)") },
                            placeholder = { Text("e.g. +919876543210") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("support_whatsapp_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = supportMessageTemplate,
                            onValueChange = { supportMessageTemplate = it },
                            label = { Text("Predefined WhatsApp Message Template") },
                            placeholder = { Text("How can we assist you?") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("support_message_input"),
                            minLines = 2
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val newSupportConfig = com.example.data.SupportConfig(
                                    whatsappNumber = supportWhatsappNumber.trim(),
                                    supportMessage = supportMessageTemplate.trim()
                                )
                                viewModel.updateSupportConfig(newSupportConfig)
                                android.widget.Toast.makeText(context, "Support settings saved successfully!", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            enabled = supportWhatsappNumber.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("support_save_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Support Details", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }

    if (showEditProductDialogProduct != null) {
        val productToEdit = showEditProductDialogProduct!!
        AlertDialog(
            onDismissRequest = { showEditProductDialogProduct = null },
            title = { Text("Edit Catalog Item", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Modify product properties for customers in real-time.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    OutlinedTextField(
                        value = editProductName,
                        onValueChange = { editProductName = it },
                        label = { Text("Product Name") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_name"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = editProductPrice,
                            onValueChange = { editProductPrice = it },
                            label = { Text("Price ($)") },
                            modifier = Modifier.weight(1f).testTag("edit_product_price"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editProductStock,
                            onValueChange = { editProductStock = it },
                            label = { Text("Stock Level") },
                            modifier = Modifier.weight(1f).testTag("edit_product_stock"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }

                    // Category Selection
                    var expandedEditCat by remember { mutableStateOf(false) }
                    Box {
                        OutlinedTextField(
                            value = editProductCategory,
                            onValueChange = {},
                            label = { Text("Category Selection") },
                            readOnly = true,
                            trailingIcon = {
                                IconButton(onClick = { expandedEditCat = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedEditCat = true }
                                .testTag("edit_product_category_field")
                        )
                        DropdownMenu(
                            expanded = expandedEditCat,
                            onDismissRequest = { expandedEditCat = false }
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        editProductCategory = cat
                                        expandedEditCat = false
                                    }
                                )
                            }
                        }
                    }

                    if (editProductCategory == "Custom Type...") {
                        OutlinedTextField(
                            value = editCustomCategoryText,
                            onValueChange = { editCustomCategoryText = it },
                            label = { Text("Specify Custom Furniture Type") },
                            placeholder = { Text("e.g. Wardrobe, Cabinet, Desk") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .testTag("edit_product_custom_category_input"),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = editProductDimens,
                        onValueChange = { editProductDimens = it },
                        label = { Text("Dimensions Size") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_dimensions"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = editProductMaterial,
                        onValueChange = { editProductMaterial = it },
                        label = { Text("Craft Material") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_material"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val editGalleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                            contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
                        ) { uri: android.net.Uri? ->
                            uri?.let { editProductImageUrl = it.toString() }
                        }

                        OutlinedTextField(
                            value = editProductImageUrl,
                            onValueChange = { editProductImageUrl = it },
                            label = { Text("Product Picture (URL or Gallery)") },
                            placeholder = { Text("https://example.com/image.jpg") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("edit_product_image_url"),
                            singleLine = true
                        )

                        IconButton(
                            onClick = { editGalleryLauncher.launch("image/*") },
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .size(48.dp)
                                .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(12.dp))
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Choose from Gallery", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    // Presets Selector Row for edit
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("OR SELECT A STUNNING STOCK PHOTO:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(2.dp))
                    val presetImages = listOf(
                        "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80&w=600" to "Emerald Sofa",
                        "https://images.unsplash.com/photo-1484101403633-562f891dc89a?auto=format&fit=crop&q=80&w=600" to "Cream Sofa",
                        "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&q=80&w=600" to "Ash Lounge",
                        "https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&q=80&w=600" to "Wood Chair",
                        "https://images.unsplash.com/photo-1577140917170-285929fb55b7?auto=format&fit=crop&q=80&w=600" to "Oak Table",
                        "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&q=80&w=600" to "Desk Office",
                        "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&q=80&w=600" to "Cozy Bed",
                        "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&q=80&w=600" to "Table Lamp",
                        "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&q=80&w=600" to "Nordic Art"
                    )
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        items(presetImages) { (url, label) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (editProductImageUrl == url) MaterialTheme.colorScheme.primaryContainer 
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    )
                                    .border(
                                        1.dp, 
                                        if (editProductImageUrl == url) MaterialTheme.colorScheme.primary 
                                        else Color.Transparent, 
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { editProductImageUrl = url }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = editProductDesc,
                        onValueChange = { editProductDesc = it },
                        label = { Text("Item Description story") },
                        modifier = Modifier.fillMaxWidth().testTag("edit_product_desc"),
                        minLines = 2
                    )

                    // Picture Color Palettes selector
                    Text(
                        "Visual Representation (Picture Theme)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    val colorsPalette = listOf(
                        0xFFD2B48C to "Beige Oak",
                        0xFFC6AC8F to "Natural Oak",
                        0xFFBC8F8F to "Rosy Walnut",
                        0xFF8B4513 to "Saddle Brown",
                        0xFFD4A373 to "Warm Sand",
                        0xFFE0D2C3 to "Soft Cream",
                        0xFF4A5D4E to "Forest Green",
                        0xFF2F4F4F to "Charcoal Slate"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        colorsPalette.forEach { (colorLong, name) ->
                            val isSelected = editProductColor == colorLong
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorLong))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray,
                                        shape = CircleShape
                                    )
                                    .clickable { editProductColor = colorLong }
                                    .testTag("color_select_$colorLong")
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsedPrice = editProductPrice.toDoubleOrNull()
                        val parsedStock = editProductStock.toIntOrNull()
                        val finalCategory = if (editProductCategory == "Custom Type...") {
                            if (editCustomCategoryText.isNotBlank()) editCustomCategoryText.trim() else "Other"
                        } else editProductCategory

                        if (editProductName.isNotBlank() && parsedPrice != null && parsedStock != null && editProductDesc.isNotBlank()) {
                            viewModel.adminUpdateProductDetails(
                                productId = productToEdit.id,
                                name = editProductName.trim(),
                                description = editProductDesc.trim(),
                                price = parsedPrice,
                                category = finalCategory,
                                stock = parsedStock,
                                material = editProductMaterial.trim(),
                                dimensions = editProductDimens.trim(),
                                imagePlaceholderColor = editProductColor,
                                imageUrl = editProductImageUrl.trim()
                            )
                            showEditProductDialogProduct = null
                        }
                    },
                    modifier = Modifier.testTag("edit_product_confirm")
                ) {
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProductDialogProduct = null }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(28.dp),
            containerColor = MaterialTheme.colorScheme.background
        )
    }
}

// ==========================================
// 12. CUSTOMER LOGIN SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerLoginScreen(
    viewModel: FurnitureViewModel,
    onLoginSuccess: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val supportConfig by viewModel.supportConfig.collectAsStateWithLifecycle()
    val localContext = LocalContext.current

    var isSignUpMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    var isError by remember { mutableStateOf(false) }

    // Admin direct PIN gate states
    var showAdminPinDialogLocal by remember { mutableStateOf(false) }
    var adminPinInputLocal by remember { mutableStateOf("") }
    var adminPinErrorLocal by remember { mutableStateOf(false) }

    if (showAdminPinDialogLocal) {
        AlertDialog(
            onDismissRequest = { 
                showAdminPinDialogLocal = false 
                adminPinInputLocal = ""
                adminPinErrorLocal = false
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AdminPanelSettings, 
                        contentDescription = null, 
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Admin Verification", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Enter the configured 4-digit store owner PIN to enter the management dashboards directly.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = adminPinInputLocal,
                        onValueChange = { 
                            if (it.length <= 4) {
                                adminPinInputLocal = it
                                adminPinErrorLocal = false
                            }
                        },
                        label = { Text("Enter 4-Digit Admin PIN") },
                        placeholder = { Text("••••") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = adminPinErrorLocal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_pin_input_local"),
                        supportingText = {
                            if (adminPinErrorLocal) {
                                Text("Incorrect administrator passcode", color = MaterialTheme.colorScheme.error)
                            } else {
                                Text("Passcode changed by store owner")
                            }
                        }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hashedPin = com.example.data.SecurityCryptoUtils.sha256(adminPinInputLocal)
                        if (hashedPin == "f74d0f06bb85ee535cdd81664c1fdf582eb8f752a083e69c8351fed904afee06") {
                            showAdminPinDialogLocal = false
                            adminPinInputLocal = ""
                            adminPinErrorLocal = false
                            onNavigateToAdmin()
                        } else {
                            adminPinErrorLocal = true
                        }
                    },
                    modifier = Modifier.testTag("submit_pin_button_local")
                ) {
                    Text("Authorize")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { 
                        showAdminPinDialogLocal = false 
                        adminPinInputLocal = ""
                        adminPinErrorLocal = false
                    }
                ) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(28.dp),
            containerColor = MaterialTheme.colorScheme.background.copy(alpha = 0.95f)
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .glassBackground(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            // Brand/Icon section
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Weekend,
                    contentDescription = "Furniture Logo",
                    modifier = Modifier.size(44.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "FURNITUREKART",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground,
                letterSpacing = 2.sp
            )

            Text(
                text = "Premium Furniture For Modern Living",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Main login card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(28.dp), lightOpacity = 0.45f, borderOpacity = 0.45f),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Segmented Button Tab Switcher
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = { isSignUpMode = false; isError = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isSignUpMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                                contentColor = if (!isSignUpMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Button(
                            onClick = { isSignUpMode = true; isError = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSignUpMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                                contentColor = if (isSignUpMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Text(
                        text = if (isSignUpMode) "Register New Customer Account" else "Customer Account Login",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; isError = false },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customer_login_name"),
                        singleLine = true
                    )

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it; isError = false },
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_login_email"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it; isError = false },
                        label = { Text("Phone Number") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("customer_login_phone"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it; isError = false },
                            label = { Text("Default Delivery Address") },
                            leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_login_address"),
                            singleLine = true
                        )
                    }

                    if (isError) {
                        Text(
                            text = if (isSignUpMode) "Please fill in all registration fields." else "Please enter your Name and Phone Number.",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            if (isSignUpMode) {
                                if (name.isBlank() || phone.isBlank() || email.isBlank() || address.isBlank()) {
                                    isError = true
                                } else {
                                    viewModel.updateProfile(name.trim(), email.trim(), phone.trim(), listOf(address.trim()))
                                    onLoginSuccess()
                                }
                            } else {
                                if (name.isBlank() || phone.isBlank()) {
                                    isError = true
                                } else {
                                    viewModel.updateProfile(name.trim(), email.trim(), phone.trim(), emptyList())
                                    onLoginSuccess()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("customer_login_submit_btn"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(if (isSignUpMode) Icons.Default.AppRegistration else Icons.Default.Login, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isSignUpMode) "Create Account & Explore" else "Log In & Explore", fontWeight = FontWeight.Bold)
                    }

                    TextButton(
                        onClick = {
                            // Demo login
                            viewModel.updateProfile("Sarah Jenkins", "sarah.jenkins@gmail.com", "+1 (555) 432-8765", listOf("1042 Birchwood Terrace, San Francisco, CA"))
                            onLoginSuccess()
                        },
                        modifier = Modifier.testTag("customer_login_demo_btn")
                    ) {
                        Text("Explore with Sarah Jenkins (Demo Profile)", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Admin Shortcut Panel Directly On Login option Page
            Card(
                onClick = { showAdminPinDialogLocal = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.5f, borderOpacity = 0.5f)
                    .testTag("admin_portal_shortcut_card"),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin Area",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "ADMINISTRATOR PORTAL", 
                            fontWeight = FontWeight.ExtraBold, 
                            fontSize = 11.sp, 
                            color = MaterialTheme.colorScheme.tertiary, 
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            "Secure access to manage catalog, orders and shop operations.", 
                            fontSize = 11.sp, 
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Prominent Customer Support Hotline Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .frostedGlass(shape = RoundedCornerShape(24.dp), lightOpacity = 0.5f, borderOpacity = 0.5f)
                    .testTag("customer_login_support_card"),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "WhatsApp Support",
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "NEED LOGIN ASSISTANCE?",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Connect with our 24/7 hotline support at ${supportConfig.whatsappNumber} for instant access and design inquiries.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            try {
                                val cleanNumber = supportConfig.whatsappNumber.replace("+", "").replace(" ", "").trim()
                                val url = "https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode("Hello! I need assistance with logging in to FurnitureKart.")}"
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = Uri.parse(url)
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                localContext.startActivity(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(localContext, "WhatsApp is not installed on this device.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("login_whatsapp_support_btn")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chat on WhatsApp Support", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}
