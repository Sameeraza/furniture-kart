package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val price: Double,
    val category: String, // Sofa, Chair, Table, Bed, Decor
    val stock: Int,
    val rating: Float = 4.5f,
    val imagePlaceholderColor: Long, // Hex color for canvas fallback
    val dimensions: String = "Standard size",
    val material: String = "Premium materials",
    val imageUrl: String = ""
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val quantity: Int
)

@Entity(tableName = "wishlist_items")
data class WishlistItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderDate: Long = System.currentTimeMillis(),
    val totalAmount: Double,
    val status: String, // Pending, Processing, Shipped, Delivered, Cancelled
    val address: String,
    val paymentMethod: String,
    val trackingProgress: Float = 0.1f, // 0.0f to 1.0f representing visual shipping progress
    val itemsSummary: String, // e.g., "Cozy Linen Sofa x1, Nordic Lounge Chair x2"
    val deliveryStatusLogs: String = "Order placed;Payment confirmed", // Semicolon-separated timeline logs
    val customerName: String = "",
    val customerEmail: String = "",
    val customerPhone: String = ""
)

@Entity(tableName = "reviews")
data class Review(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val userName: String,
    val rating: Int, // 1 to 5
    val comment: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1, // Only one active profile
    val name: String,
    val email: String,
    val phone: String,
    val savedAddresses: String // Semicolon-separated list of addresses
)
