package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class FurnitureRepository(private val database: AppDatabase) {

    private val productDao = database.productDao()
    private val cartDao = database.cartDao()
    private val wishlistDao = database.wishlistDao()
    private val orderDao = database.orderDao()
    private val reviewDao = database.reviewDao()
    private val userProfileDao = database.userProfileDao()

    // Products
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()

    fun getProductById(id: Int): Flow<Product?> = productDao.getProductById(id)

    suspend fun insertProduct(product: Product) = productDao.insertProduct(product)

    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)

    suspend fun updateStock(productId: Int, newStock: Int) = productDao.updateStock(productId, newStock)

    suspend fun deleteProductById(id: Int) = productDao.deleteProductById(id)

    suspend fun deleteAllProducts() = productDao.deleteAllProducts()

    // Cart
    val cartItems: Flow<List<CartItem>> = cartDao.getCartItems()

    suspend fun addToCart(productId: Int, quantity: Int = 1) {
        // Query current cart items
        // Since we are inside a coroutine, we can read the current flow value (first())
        val currentItems = cartDao.getCartItems().first()
        val existing = currentItems.find { it.productId == productId }
        if (existing != null) {
            cartDao.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
        } else {
            cartDao.insertCartItem(CartItem(productId = productId, quantity = quantity))
        }
    }

    suspend fun updateCartItemQuantity(cartItemId: Int, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.deleteCartItem(cartItemId)
        } else {
            val currentItems = cartDao.getCartItems().first()
            val existing = currentItems.find { it.id == cartItemId }
            if (existing != null) {
                cartDao.updateCartItem(existing.copy(quantity = newQuantity))
            }
        }
    }

    suspend fun removeFromCart(cartItemId: Int) {
        cartDao.deleteCartItem(cartItemId)
    }

    suspend fun clearCart() = cartDao.clearCart()

    // Wishlist
    val wishlistItems: Flow<List<WishlistItem>> = wishlistDao.getWishlistItems()

    fun isWishlisted(productId: Int): Flow<Boolean> = wishlistDao.isWishlisted(productId)

    suspend fun toggleWishlist(productId: Int) {
        val currentItems = wishlistDao.getWishlistItems().first()
        val existing = currentItems.find { it.productId == productId }
        if (existing != null) {
            wishlistDao.deleteWishlistItemByProductId(productId)
        } else {
            wishlistDao.insertWishlistItem(WishlistItem(productId = productId))
        }
    }

    // Orders & Tracking
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()

    fun getOrderById(id: Int): Flow<Order?> = orderDao.getOrderById(id)

    suspend fun placeOrder(
        totalAmount: Double, 
        address: String, 
        paymentMethod: String, 
        itemsSummary: String,
        customerName: String = "",
        customerEmail: String = "",
        customerPhone: String = ""
    ): Long {
        val order = Order(
            totalAmount = totalAmount,
            status = "Processing",
            address = address,
            paymentMethod = paymentMethod,
            trackingProgress = 0.2f,
            itemsSummary = itemsSummary,
            deliveryStatusLogs = "Order Placed;Payment Confirmed;Processing at San Jose Warehouse",
            customerName = customerName,
            customerEmail = customerEmail,
            customerPhone = customerPhone
        )
        return orderDao.insertOrder(order)
    }

    suspend fun updateOrderStatus(orderId: Int, status: String, progress: Float, logs: String) {
        orderDao.updateOrderStatus(orderId, status, progress, logs)
    }

    // Reviews
    fun getReviewsForProduct(productId: Int): Flow<List<Review>> = reviewDao.getReviewsForProduct(productId)

    suspend fun addReview(productId: Int, userName: String, rating: Int, comment: String) {
        reviewDao.insertReview(
            Review(
                productId = productId,
                userName = userName,
                rating = rating,
                comment = comment
            )
        )
    }

    // User Profile
    val userProfile: Flow<UserProfile?> = userProfileDao.getUserProfile()

    suspend fun updateProfile(profile: UserProfile) = userProfileDao.saveUserProfile(profile)
}
