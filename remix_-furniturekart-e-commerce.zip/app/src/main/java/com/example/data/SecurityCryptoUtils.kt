package com.example.data

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.security.MessageDigest

object SecurityCryptoUtils {
    private const val ALGORITHM = "AES/CBC/PKCS5Padding"
    private val MASTER_KEY_RAW = "FurnitureKartSecureSymmetricSecretKey2026MasterKey".toByteArray()
    
    // Hash helper
    fun sha256(input: String, salt: String = "FurnitureKartSecureSalt2026"): String {
        return try {
            val bytes = (input + salt).toByteArray(Charsets.UTF_8)
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            digest.fold("") { str, it -> str + "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    // AES encryption
    fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        return try {
            val keyBytes = MessageDigest.getInstance("SHA-256").digest(MASTER_KEY_RAW)
            val secretKey = SecretKeySpec(keyBytes, "AES")
            
            // Fixed IV derived from hash for deterministic offline decryption
            val ivBytes = MessageDigest.getInstance("MD5").digest("FurnitureKartSecureIV".toByteArray())
            val ivSpec = IvParameterSpec(ivBytes)

            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec)
            
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encryptedBytes, Base64.DEFAULT).trim()
        } catch (e: Exception) {
            plainText // Fallback in case of absolute failure
        }
    }

    // AES decryption
    fun decrypt(encryptedText: String): String {
        if (encryptedText.isEmpty()) return ""
        return try {
            val keyBytes = MessageDigest.getInstance("SHA-256").digest(MASTER_KEY_RAW)
            val secretKey = SecretKeySpec(keyBytes, "AES")

            val ivBytes = MessageDigest.getInstance("MD5").digest("FurnitureKartSecureIV".toByteArray())
            val ivSpec = IvParameterSpec(ivBytes)

            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec)

            val decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT)
            val decryptedBytes = cipher.doFinal(decodedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            encryptedText // Fallback to raw if not encrypted or error
        }
    }
}
