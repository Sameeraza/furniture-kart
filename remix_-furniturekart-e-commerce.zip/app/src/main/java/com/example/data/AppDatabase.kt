package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY id ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    fun getProductById(id: Int): Flow<Product?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)

    @Query("UPDATE products SET stock = :newStock WHERE id = :productId")
    suspend fun updateStock(productId: Int, newStock: Int)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: Int)

    @Query("DELETE FROM products")
    suspend fun deleteAllProducts()
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItem)

    @Update
    suspend fun updateCartItem(item: CartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items WHERE productId = :productId")
    suspend fun deleteCartItemByProductId(productId: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlist_items")
    fun getWishlistItems(): Flow<List<WishlistItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlistItem(item: WishlistItem)

    @Query("DELETE FROM wishlist_items WHERE productId = :productId")
    suspend fun deleteWishlistItemByProductId(productId: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist_items WHERE productId = :productId)")
    fun isWishlisted(productId: Int): Flow<Boolean>
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY orderDate DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderById(id: Int): Flow<Order?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    @Update
    suspend fun updateOrder(order: Order)

    @Query("UPDATE orders SET status = :status, trackingProgress = :progress, deliveryStatusLogs = :logs WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Int, status: String, progress: Float, logs: String)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE productId = :productId ORDER BY timestamp DESC")
    fun getReviewsForProduct(productId: Int): Flow<List<Review>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review)
}

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfile)
}

@Database(
    entities = [
        Product::class,
        CartItem::class,
        WishlistItem::class,
        Order::class,
        Review::class,
        UserProfile::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun wishlistDao(): WishlistDao
    abstract fun orderDao(): OrderDao
    abstract fun reviewDao(): ReviewDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "furniture_kart_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }

        // Seeding function to populate with premium initial data
        suspend fun seedIfNeeded(database: AppDatabase) {
            val productDao = database.productDao()
            val existingProducts = productDao.getAllProducts().first()
            if (existingProducts.isEmpty()) {
                val seedProducts = listOf(
                    Product(
                        id = 1,
                        name = "Cozy Boucle Lounge Sofa",
                        description = "Enveloped in luxurious, heavy-textured boucle wool fabric, this deep-seated lounge sofa features organic rounded contours and an ultra-plush density foam. Framed in premium kiln-dried white oak for structural integrity, it is the perfect central statement piece for any modern living space.",
                        price = 899.99,
                        category = "Sofa",
                        stock = 6,
                        rating = 4.8f,
                        imagePlaceholderColor = 0xFFE6DFD3, // Warm beige
                        dimensions = "84\" W x 38\" D x 32\" H",
                        material = "Italian Wool Bouclé & Kiln-Dried White Oak"
                    ),
                    Product(
                        id = 2,
                        name = "Nordic Ash Accent Chair",
                        description = "Inspired by classic mid-century Scandinavian carpentry. This lounge chair showcases a beautifully tapered light ash wood frame, masterfully hand-sanded to perfection. Featuring a high-resiliency organic linen cushion in soft sand grey, it offers ergonomic support with timeless style.",
                        price = 249.99,
                        category = "Chair",
                        stock = 12,
                        rating = 4.6f,
                        imagePlaceholderColor = 0xFFD3C8BE, // Ash rose grey
                        dimensions = "28\" W x 30\" D x 34\" H",
                        material = "Solid Ash Wood & Belgian Linen"
                    ),
                    Product(
                        id = 3,
                        name = "Live-Edge Solid Oak Dining Table",
                        description = "A striking showcase of raw, organic natural beauty. Crafted from a massive piece of sustainably harvested solid French white oak, maintaining its unique live edge. Supported by an architecturally bold, heavy-duty matte black steel powder-coated base.",
                        price = 649.99,
                        category = "Table",
                        stock = 4,
                        rating = 4.9f,
                        imagePlaceholderColor = 0xFFC6AC8F, // Peru wood brown
                        dimensions = "72\" W x 36\" D x 30\" H",
                        material = "Solid French White Oak & Industrial Steel"
                    ),
                    Product(
                        id = 4,
                        name = "Minimalist Platform Storage Bed",
                        description = "Clean lines and multi-functional modern design. This low-profile platform bed features a beautiful walnut wood veneer frame, complete with integrated soft-closing hydraulic under-bed drawer storage. Fits standard Queen mattress; no box spring required.",
                        price = 799.99,
                        category = "Bed",
                        stock = 3,
                        rating = 4.7f,
                        imagePlaceholderColor = 0xFF5C4033, // Dark walnut
                        dimensions = "Queen Size (65\" W x 86\" L x 42\" H)",
                        material = "American Walnut Veneer & Hardwood Core"
                    ),
                    Product(
                        id = 5,
                        name = "Ceramic Ribbed Table Lamp",
                        description = "An sculptural light source that adds warmth to any corner. Hand-crafted ceramic base featuring clean, rhythmic vertical ribbing and finished in a subtle, speckled stone-grey matte glaze. Complemented by a premium natural linen drum shade.",
                        price = 89.99,
                        category = "Decor",
                        stock = 24,
                        rating = 4.4f,
                        imagePlaceholderColor = 0xFFE0D2C3, // Burlywood light
                        dimensions = "12\" Diameter x 22\" H",
                        material = "Ribbed Ceramic & Speckled Matte Glaze"
                    ),
                    Product(
                        id = 6,
                        name = "Bouclé Arch Geometric Pillow",
                        description = "An elegant decorative pillow made from ultra-soft wool boucle. Styled with an embroidered minimalist arch motif, bringing soft touch textures and a high-contrast geometric highlight to your lounge chairs or sofas.",
                        price = 39.99,
                        category = "Decor",
                        stock = 45,
                        rating = 4.5f,
                        imagePlaceholderColor = 0xFFD4A373, // Clay gold
                        dimensions = "18\" W x 18\" H",
                        material = "Wool Bouclé Blend & Down-Alternative Fill"
                    )
                )

                seedProducts.forEach { productDao.insertProduct(it) }

                // Seed some initial reviews
                val reviewDao = database.reviewDao()
                val seedReviews = listOf(
                    Review(productId = 1, userName = "Alexander G.", rating = 5, comment = "Absolutely spectacular! The boucle texture feels incredibly high quality and looks like an expensive designer sofa. Super comfortable."),
                    Review(productId = 1, userName = "Sophia M.", rating = 4, comment = "Very nice and cozy. It's firm but comfortable. Minor delay in scheduling delivery, but the sofa itself is flawless."),
                    Review(productId = 2, userName = "Liam T.", rating = 5, comment = "Minimalist perfection. Frame is solid ash wood, very heavy and sturdy. Cushion fits perfectly into the lounge layout."),
                    Review(productId = 3, userName = "Isabella K.", rating = 5, comment = "A true masterpiece! The live edge of the oak wood is so unique and gets compliments from every dinner guest. Base is rock solid."),
                    Review(productId = 4, userName = "Daniel R.", rating = 4, comment = "The hydraulic drawers are a lifesaver in a compact apartment. Instructions were easy, but assembly takes 2 people.")
                )
                seedReviews.forEach { reviewDao.insertReview(it) }

                // Seed default user profile
                val profileDao = database.userProfileDao()
                profileDao.saveUserProfile(
                    UserProfile(
                        id = 1,
                        name = "Sarah Jenkins",
                        email = "sarah.jenkins@gmail.com",
                        phone = "+1 (555) 432-8765",
                        savedAddresses = "1042 Birchwood Terrace, Apt 4B, San Francisco, CA 94109;872 Maple Avenue, Suite 100, Seattle, WA 98101"
                    )
                )
            }
        }
    }
}
