package com.example.data

import android.content.Context

data class SupportConfig(
    val whatsappNumber: String = "+916206366989", // Default support WhatsApp number
    val supportMessage: String = "Hello FurnitureKart Support! I need help with my furniture selection/order."
)

object SupportConfigManager {
    private const val PREFS_NAME = "support_config_settings"
    private const val KEY_WHATSAPP_NUMBER = "whatsapp_number"
    private const val KEY_SUPPORT_MESSAGE = "support_message"

    fun getSupportConfig(context: Context): SupportConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return SupportConfig(
            whatsappNumber = prefs.getString(KEY_WHATSAPP_NUMBER, "+916206366989") ?: "+916206366989",
            supportMessage = prefs.getString(KEY_SUPPORT_MESSAGE, "Hello FurnitureKart Support! I need help with my furniture selection/order.") ?: "Hello FurnitureKart Support! I need help with my furniture selection/order."
        )
    }

    fun saveSupportConfig(context: Context, config: SupportConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_WHATSAPP_NUMBER, config.whatsappNumber)
            .putString(KEY_SUPPORT_MESSAGE, config.supportMessage)
            .apply()
    }
}
