package com.example.data

import android.content.Context

data class CloudSyncConfig(
    val channelId: String = "global_furniture_store", // Default shared store ID
    val autoPush: Boolean = true,                      // Instantly upload when admin updates
    val autoPull: Boolean = true                       // Instantly fetch on app open
)

object CloudSyncConfigManager {
    private const val PREFS_NAME = "cloud_sync_config"
    private const val KEY_CHANNEL_ID = "channel_id"
    private const val KEY_AUTO_PUSH = "auto_push"
    private const val KEY_AUTO_PULL = "auto_pull"

    fun getConfig(context: Context): CloudSyncConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return CloudSyncConfig(
            channelId = prefs.getString(KEY_CHANNEL_ID, "global_furniture_store") ?: "global_furniture_store",
            autoPush = prefs.getBoolean(KEY_AUTO_PUSH, true),
            autoPull = prefs.getBoolean(KEY_AUTO_PULL, true)
        )
    }

    fun saveConfig(context: Context, config: CloudSyncConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_CHANNEL_ID, config.channelId.trim())
            .putBoolean(KEY_AUTO_PUSH, config.autoPush)
            .putBoolean(KEY_AUTO_PULL, config.autoPull)
            .apply()
    }
}
