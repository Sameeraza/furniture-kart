package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

data class SmtpConfig(
    val enabled: Boolean = false,
    val smtpHost: String = "smtp.gmail.com",
    val smtpPort: String = "587",
    val username: String = "",
    val password: String = "",
    val recipient: String = "samyzzsecret@gmail.com",
    val useSsl: Boolean = false
)

object EmailSender {
    private const val PREFS_NAME = "smtp_email_settings"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_HOST = "smtp_host"
    private const val KEY_PORT = "smtp_port"
    private const val KEY_USER = "smtp_username"
    private const val KEY_PASS = "smtp_password"
    private const val KEY_RECIPIENT = "smtp_recipient"
    private const val KEY_USE_SSL = "smtp_use_ssl"

    fun getSmtpConfig(context: Context): SmtpConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawPassword = prefs.getString(KEY_PASS, "") ?: ""
        return SmtpConfig(
            enabled = prefs.getBoolean(KEY_ENABLED, false),
            smtpHost = prefs.getString(KEY_HOST, "smtp.gmail.com") ?: "smtp.gmail.com",
            smtpPort = prefs.getString(KEY_PORT, "587") ?: "587",
            username = prefs.getString(KEY_USER, "") ?: "",
            password = SecurityCryptoUtils.decrypt(rawPassword),
            recipient = prefs.getString(KEY_RECIPIENT, "samyzzsecret@gmail.com") ?: "samyzzsecret@gmail.com",
            useSsl = prefs.getBoolean(KEY_USE_SSL, false)
        )
    }

    fun saveSmtpConfig(context: Context, config: SmtpConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_ENABLED, config.enabled)
            .putString(KEY_HOST, config.smtpHost)
            .putString(KEY_PORT, config.smtpPort)
            .putString(KEY_USER, config.username)
            .putString(KEY_PASS, SecurityCryptoUtils.encrypt(config.password))
            .putString(KEY_RECIPIENT, config.recipient)
            .putBoolean(KEY_USE_SSL, config.useSsl)
            .apply()
    }

    suspend fun sendEmail(config: SmtpConfig, subject: String, body: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (config.username.isBlank() || config.password.isBlank()) {
                return@withContext Result.failure(Exception("Sender credentials are empty. Please configure SMTP credentials in Admin panel."))
            }

            val props = Properties()
            props["mail.smtp.host"] = config.smtpHost
            props["mail.smtp.port"] = config.smtpPort
            props["mail.smtp.auth"] = "true"

            if (config.useSsl) {
                props["mail.smtp.socketFactory.port"] = config.smtpPort
                props["mail.smtp.socketFactory.class"] = "javax.net.ssl.SSLSocketFactory"
                props["mail.smtp.socketFactory.fallback"] = "false"
            } else {
                // TLS
                props["mail.smtp.starttls.enable"] = "true"
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(config.username, config.password)
                }
            })

            val message = MimeMessage(session)
            message.setFrom(InternetAddress(config.username))
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(config.recipient))
            message.subject = subject
            message.setText(body)

            Transport.send(message)
            Log.d("EmailSender", "Email sent successfully to ${config.recipient}")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("EmailSender", "Failed to send email", e)
            Result.failure(e)
        }
    }
}
