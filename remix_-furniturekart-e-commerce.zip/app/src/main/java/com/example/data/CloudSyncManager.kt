package com.example.data

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object CloudSyncManager {
    private const val TAG = "CloudSyncManager"
    
    // An open, public kvdb.io bucket key for our application's shared databases
    private const val BUCKET_KEY = "An8N5R89m3DkWL1vD8yU6E"
    private const val BASE_URL = "https://kvdb.io/$BUCKET_KEY"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Uploads the local product catalog list to the cloud channel.
     */
    suspend fun uploadCatalog(channelId: String, products: List<Product>): Result<Boolean> {
        return withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val jsonArray = JSONArray()
                products.forEach { product ->
                    val obj = JSONObject().apply {
                        put("id", product.id)
                        put("name", product.name)
                        put("description", product.description)
                        put("price", product.price)
                        put("category", product.category)
                        put("stock", product.stock)
                        put("rating", product.rating.toDouble())
                        put("imagePlaceholderColor", product.imagePlaceholderColor)
                        put("dimensions", product.dimensions)
                        put("material", product.material)
                        put("imageUrl", product.imageUrl)
                    }
                    jsonArray.put(obj)
                }

                val requestBody = jsonArray.toString().toRequestBody(jsonMediaType)
                val url = "$BASE_URL/fk_catalog_${channelId.lowercase().trim()}"
                
                val request = Request.Builder()
                    .url(url)
                    .put(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        Log.d(TAG, "Successfully uploaded catalog to $url")
                        Result.success(true)
                    } else {
                        val errBody = response.body?.string() ?: ""
                        Log.e(TAG, "Failed to upload catalog: ${response.code} $errBody")
                        Result.failure(Exception("Server returned code ${response.code}: $errBody"))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception during upload", e)
                Result.failure(e)
            }
        }
    }

    /**
     * Fetches the product catalog list from the cloud channel.
     */
    suspend fun fetchCatalog(channelId: String): Result<List<Product>> {
        return withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val url = "$BASE_URL/fk_catalog_${channelId.lowercase().trim()}"
                val request = Request.Builder()
                    .url(url)
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val bodyString = response.body?.string()
                        if (bodyString.isNullOrBlank()) {
                            return@withContext Result.success(emptyList())
                        }
                        
                        val jsonArray = JSONArray(bodyString)
                        val products = mutableListOf<Product>()
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val product = Product(
                                id = obj.optInt("id", 0),
                                name = obj.optString("name", "Unnamed Item"),
                                description = obj.optString("description", ""),
                                price = obj.optDouble("price", 0.0),
                                category = obj.optString("category", "Sofa"),
                                stock = obj.optInt("stock", 1),
                                rating = obj.optDouble("rating", 4.5).toFloat(),
                                imagePlaceholderColor = obj.optLong("imagePlaceholderColor", 0xFFD2B48C),
                                dimensions = obj.optString("dimensions", "Standard size"),
                                material = obj.optString("material", "Premium wood"),
                                imageUrl = obj.optString("imageUrl", "")
                            )
                            products.add(product)
                        }
                        Log.d(TAG, "Successfully fetched ${products.size} products from $url")
                        Result.success(products)
                    } else if (response.code == 404) {
                        // Channel not found / empty yet
                        Log.d(TAG, "Catalog channel $url not found (empty)")
                        Result.success(emptyList())
                    } else {
                        val errBody = response.body?.string() ?: ""
                        Log.e(TAG, "Failed to fetch catalog: ${response.code} $errBody")
                        Result.failure(Exception("Server returned code ${response.code}: $errBody"))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception during fetch", e)
                Result.failure(e)
            }
        }
    }
}

// Inline helper helper since withContext is from kotlinx.coroutines
private suspend fun <T> withContext(
    context: kotlin.coroutines.CoroutineContext,
    block: suspend kotlinx.coroutines.CoroutineScope.() -> T
): T = kotlinx.coroutines.withContext(context, block)
