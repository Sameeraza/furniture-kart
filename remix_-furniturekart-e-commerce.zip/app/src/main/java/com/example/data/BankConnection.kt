package com.example.data

import android.content.Context

data class BankConfig(
    val isConnected: Boolean = false,
    val bankName: String = "",
    val accountNumber: String = "",
    val ifscCode: String = "",
    val accountHolderName: String = "",
    val upiId: String = ""
)

object BankConnectionManager {
    private const val PREFS_NAME = "bank_connection_settings"
    private const val KEY_CONNECTED = "is_connected"
    private const val KEY_BANK_NAME = "bank_name"
    private const val KEY_ACC_NUM = "account_number"
    private const val KEY_IFSC = "ifsc_code"
    private const val KEY_HOLDER = "account_holder"
    private const val KEY_UPI = "upi_id"

    fun getBankConfig(context: Context): BankConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawBankName = prefs.getString(KEY_BANK_NAME, "") ?: ""
        val rawAccNum = prefs.getString(KEY_ACC_NUM, "") ?: ""
        val rawIfsc = prefs.getString(KEY_IFSC, "") ?: ""
        val rawHolder = prefs.getString(KEY_HOLDER, "") ?: ""
        val rawUpi = prefs.getString(KEY_UPI, "") ?: ""

        return BankConfig(
            isConnected = prefs.getBoolean(KEY_CONNECTED, false),
            bankName = SecurityCryptoUtils.decrypt(rawBankName),
            accountNumber = SecurityCryptoUtils.decrypt(rawAccNum),
            ifscCode = SecurityCryptoUtils.decrypt(rawIfsc),
            accountHolderName = SecurityCryptoUtils.decrypt(rawHolder),
            upiId = SecurityCryptoUtils.decrypt(rawUpi)
        )
    }

    fun saveBankConfig(context: Context, config: BankConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_CONNECTED, config.isConnected)
            .putString(KEY_BANK_NAME, SecurityCryptoUtils.encrypt(config.bankName))
            .putString(KEY_ACC_NUM, SecurityCryptoUtils.encrypt(config.accountNumber))
            .putString(KEY_IFSC, SecurityCryptoUtils.encrypt(config.ifscCode))
            .putString(KEY_HOLDER, SecurityCryptoUtils.encrypt(config.accountHolderName))
            .putString(KEY_UPI, SecurityCryptoUtils.encrypt(config.upiId))
            .apply()
    }
}
