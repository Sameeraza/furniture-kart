package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.FurnitureViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val navController = rememberNavController()
        val viewModel: FurnitureViewModel = viewModel()

        Surface(
          modifier = Modifier.fillMaxSize(),
          color = MaterialTheme.colorScheme.background
        ) {
          NavHost(
            navController = navController,
            startDestination = "customer_login"
          ) {
            composable("customer_login") {
              CustomerLoginScreen(
                viewModel = viewModel,
                onLoginSuccess = {
                  navController.navigate("dashboard") {
                    popUpTo("customer_login") { inclusive = true }
                  }
                },
                onNavigateToAdmin = {
                  navController.navigate("admin")
                }
              )
            }

            composable("dashboard") {
              CustomerDashboardScreen(
                viewModel = viewModel,
                onNavigateToProduct = { id -> navController.navigate("detail/$id") },
                onNavigateToCart = { navController.navigate("cart") },
                onNavigateToProfile = { navController.navigate("profile") },
                onNavigateToAdmin = { navController.navigate("admin") }
              )
            }
            
            composable(
              route = "detail/{productId}",
              arguments = listOf(navArgument("productId") { type = NavType.IntType })
            ) { backStackEntry ->
              val productId = backStackEntry.arguments?.getInt("productId") ?: 1
              ProductDetailScreen(
                productId = productId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
              )
            }

            composable("cart") {
              CartScreen(
                viewModel = viewModel,
                onNavigateToCheckout = { navController.navigate("checkout") },
                onNavigateBack = { navController.popBackStack() }
              )
            }

            composable("checkout") {
              CheckoutScreen(
                viewModel = viewModel,
                onNavigateToTracking = { orderId -> navController.navigate("tracking/$orderId") },
                onNavigateBack = { navController.popBackStack() }
              )
            }

            composable(
              route = "tracking/{orderId}",
              arguments = listOf(navArgument("orderId") { type = NavType.IntType })
            ) { backStackEntry ->
              val orderId = backStackEntry.arguments?.getInt("orderId") ?: 1
              OrderTrackingScreen(
                orderId = orderId,
                viewModel = viewModel,
                onNavigateBack = { 
                  navController.navigate("dashboard") { 
                    popUpTo("dashboard") { inclusive = false } 
                  } 
                }
              )
            }

            composable("profile") {
              UserProfileScreen(
                viewModel = viewModel,
                onNavigateToOrder = { orderId -> navController.navigate("tracking/$orderId") },
                onNavigateToProduct = { id -> navController.navigate("detail/$id") },
                onNavigateBack = { navController.popBackStack() }
              )
            }

            composable("admin") {
              AdminDashboardScreen(
                viewModel = viewModel,
                onNavigateToOrderTracking = { orderId -> navController.navigate("tracking/$orderId") },
                onNavigateBack = { navController.popBackStack() }
              )
            }
          }
        }
      }
    }
  }
}

